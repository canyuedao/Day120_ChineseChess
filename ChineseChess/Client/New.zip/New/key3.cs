﻿using UnityEngine;
using System.Collections;
//登陆按钮
public class key3 : MonoBehaviour {
    public static int land = 0;
    public int key3_send;
	// Use this for initialization
	void Start () {
	
	}
    void OnMouseDown()
    {
        if (land == 0)
        {
            land = 1;

        }
    }
    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }
	void Update () {
        key3_send = datapackage.send;
        if (key3_send == 5)
        {
            land = 0;
        }
       
	}
}



