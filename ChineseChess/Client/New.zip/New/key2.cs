﻿using UnityEngine;
using System.Collections;
//不同意按钮
public class key2 : MonoBehaviour {
    public static int nokey;
    public int key2_send = 0;
	void Start () {
        nokey = 0;
    }
 
    void OnMouseDown()
    {
        nokey = 1;
    }

    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }

	void Update ()
    {
        key2_send = datapackage.send;
        if (key2_send == 2)
        {
            nokey = 0;
            Debug.Log("NO++++++++++++++++++++++");
        }
    }
}
