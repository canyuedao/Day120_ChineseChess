﻿using UnityEngine;
using System.Collections;

namespace System.VehicleMove.VMove
{ 
public class VehicleMove : MonoBehaviour {
    int ChessPositionX1;
    int ChessPositionY1;
    int ChessPositionX2;
    int ChessPositionY2;
    int ChessPositionX3;
    int ChessPositionY3;
    ChessBoard gain;

    //GameObject Mark
   // public static int ICount;
    bool Istar = false;                 //点击第一次的锁
    bool Istar1 = false;                 //点击第二次的锁
  //  public static bool ss = false;
    int[] seekX=new int[16];              //自己所有棋子的横坐标
    int[] seekY=new int[16];
    public static int[] MoveMent;          //保存可走的位置
    public static int[] MoveMentX;
    public static int[] MoveMentY;
    public static int INumber1;              //能走的位置的个数
    public static bool sound = false;          // 将军锁
    public AudioSource music;
    public float musicVolume;
    // Use this for initialization
	void Start () {
        MoveMent = new int[20];
        MoveMentX = new int[20];
         MoveMentY = new int[20];
        ////INumber1 = 0;
        //music = GameObject.Find("admiral").GetComponent<AudioSource>();
        //musicVolume = 0.5f;
    }

  void Move(int x,int y)
    {
      int INumber=0;
       // ICount++;
        //INumber = 0;
        //车
        INumber1 = -1; 
           if (ChessBoard.istate2[x, y] == 001)
            {
               {
                   bool GUNIster = false;
                   bool GUNIster1 = false;
                   bool GUNIster2 = false;
                   bool GUNIster3 = false;
                   int kk = 0;
                   for (int i = 1; i + x <= 9; i++)   //循环判断相邻处是否有棋子
                   {
                       if (ChessBoard.istate3[x + i, y] == 0)
                       {

                           MoveMent[INumber] = ChessBoard.istate3[x + i, y];
                           MoveMentX[INumber] = x + i;
                           MoveMentY[INumber] = y;
                           INumber1 = INumber;
                           INumber++;
                           //Debug.Log("1111111");
                       }
                       if (ChessBoard.istate3[x + i, y] != 0)
                       {
                           kk = x + i;
                           GUNIster = true;
                           break;
                       }
                   }
                   if (GUNIster == true)
                   {
                       if (ChessBoard.istate1[x, y] != ChessBoard.istate1[kk, y])
                       {
                           MoveMent[INumber] = ChessBoard.istate3[kk, y];
                           MoveMentX[INumber] = kk;
                           MoveMentY[INumber] = y;
                           INumber1 = INumber;
                           INumber++;
                       }
                   }
                   for (int i = 1; x - i >= 0; i++)
                   {
                       if (ChessBoard.istate3[x - i, y] == 0)
                       {
                           MoveMent[INumber] = ChessBoard.istate3[x - i, y];
                           MoveMentX[INumber] = x - i;
                           MoveMentY[INumber] = y;
                           INumber1 = INumber;
                           INumber++;
                       }
                       if (ChessBoard.istate3[x - i, y] != 0)
                       {
                           kk = x - i;
                           GUNIster1 = true;
                           break;
                       }
                   }
                   if (GUNIster1 == true)
                   {
                       if (ChessBoard.istate1[x, y] != ChessBoard.istate1[kk, y])
                       {
                           MoveMent[INumber] = ChessBoard.istate3[kk, y];
                           MoveMentX[INumber] = kk;
                           MoveMentY[INumber] = y;
                           INumber1 = INumber;
                           INumber++;
                       }
                   }
                   for (int i = 1; y + i <= 8; i++)
                   {
                       if (ChessBoard.istate3[x, y + i] == 0)
                       {
                           MoveMent[INumber] = ChessBoard.istate3[x, y + i];
                           MoveMentX[INumber] = x;
                           MoveMentY[INumber] = y + i;
                           INumber1 = INumber;
                           INumber++;
                       }
                       if (ChessBoard.istate3[x, y + i] != 0)
                       {
                           kk = y + i;
                           GUNIster2 = true;
                           break;
                       }
                   }
                   if (GUNIster2 == true)
                   {
                       if (ChessBoard.istate1[x, y] != ChessBoard.istate1[x, kk])
                       {
                           MoveMent[INumber] = ChessBoard.istate3[x, kk];
                           MoveMentX[INumber] = x;
                           MoveMentY[INumber] = kk;
                           INumber1 = INumber;
                           INumber++;
                       }
                   }
                   for (int i = 1; y - i >= 0; i++)
                   {
                       if (ChessBoard.istate3[x, y - i] == 0)
                       {
                           MoveMent[INumber] = ChessBoard.istate3[x, y - i];
                           MoveMentX[INumber] = x;
                           MoveMentY[INumber] = y - i;
                           INumber1 = INumber;
                           INumber++;
                       }
                       if (ChessBoard.istate3[x, y - i] != 0)
                       {
                           kk = y - i;
                           GUNIster3 = true;
                           break;
                       }
                   }
                   if (GUNIster3 == true)
                   {
                       if (ChessBoard.istate1[x, y] != ChessBoard.istate1[x, kk])
                       {
                           MoveMent[INumber] = ChessBoard.istate3[x, kk];
                           MoveMentX[INumber] = x;
                           MoveMentY[INumber] = kk;
                           Debug.Log(MoveMentX[INumber]);
                           INumber1 = INumber;
                           INumber++;
                       }
                   }
               }

            }


            //马
            if (ChessBoard.istate2[x, y] == 002)
            {
                for (int j = 0; j < 2;j++ )
                {
                  if (x - 2 * j + 1 < 9 && x - 2 * j + 1>0)
                  {
                    if (ChessBoard.istate3[x - 2 * j + 1, y] == 0)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (y + 2 * i - 1 >= 0 && y + 2 * i - 1 <= 8)
                            {
                                if ((ChessBoard.istate3[x - 4 * j + 2, y + 2 * i - 1] == 0 || (ChessBoard.istate3[x - 4 * j + 2, y + 2 * i - 1] != 0 && ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 4 * j + 2, y + 2 * i - 1])))
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x - 4 * j + 2, y + 2 * i - 1];
                                    MoveMentX[INumber] = x - 4 * j + 2;
                                    MoveMentY[INumber] = y + 2 * i - 1;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                     }
                   }
                 }
                for (int j = 0; j < 2;j++ )
                {
                    if (y - 2 * j + 1 < 8 && y - 2 * j + 1>0)
                    {
                        if (ChessBoard.istate3[x, y - 2 * j + 1] == 0)
                        {
                            for (int i = 0; i < 2; i++)
                            {
                                if (x + 2 * i - 1 >= 0 && x + 2 * i - 1 <= 9)
                                {
                                    if (ChessBoard.istate3[x + 2 * i - 1, y - 4 * j + 2] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 2 * i - 1, y - 4 * j + 2])
                                    {
                                        MoveMent[INumber] = ChessBoard.istate3[x + 2 * i - 1, y - 4 * j + 2];
                                        MoveMentX[INumber] = x + 2 * i - 1;
                                        MoveMentY[INumber] = y - 4 * j + 2;
                                        INumber1 = INumber;
                                        INumber++;
                                    }
                                }

                            }
                        }
                    }
                }
            }
            //象
            if (ChessBoard.istate2[x, y] == 003)
            {
                if (ChessBoard.istate[x,y]==1)
                {
               if (ChessBoard.istate1[x, y] == 5)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        if (x + 1 < 4 && y + 2 * i - 1 > 0 && y + 2 * i - 1 < 8)
                        {
                            if (ChessBoard.istate3[x + 1, y + 2 * i - 1] == 0)
                            {
                                if (ChessBoard.istate3[x + 2, y + 4 * i - 2] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 2, y + 4 * i - 2])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x + 2, y + 4 * i - 2];
                                    MoveMentX[INumber] = x + 2;
                                    MoveMentY[INumber] = y + 4 * i - 2;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }

                        }
                    }
                    for (int i = 0; i < 2; i++)
                    {
                        if (x - 1 > 0 && y + 2 * i - 1 > 0 && y + 2 * i - 1 < 8)
                        {
                            if (ChessBoard.istate3[x - 1, y + 2 * i - 1] == 0)
                            {
                                if (ChessBoard.istate3[x - 2, y + 4 * i - 2] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 2, y + 4 * i - 2])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x - 2, y + 4 * i - 2];
                                    MoveMentX[INumber] = x - 2;
                                    MoveMentY[INumber] = y + 4 * i - 2;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                    }
                }


                if (ChessBoard.istate1[x, y] == 6)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        if (x + 1 < 9 && y + 2 * i - 1 > 0 && y + 2 * i - 1 < 8)
                        {
                            if (ChessBoard.istate3[x + 1, y + 2 * i - 1] == 0)
                            {
                                if (ChessBoard.istate3[x + 2, y + 4 * i - 2] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 2, y + 4 * i - 2])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x + 2, y + 4 * i - 2];
                                    MoveMentX[INumber] = x + 2;
                                    MoveMentY[INumber] = y + 4 * i - 2;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                        if (x - 1 > 5 && y + 2 * i - 1 > 0 && y + 2 * i - 1 < 8)
                        {
                            if (ChessBoard.istate3[x - 1, y + 2 * i - 1] == 0)
                            {
                                if (ChessBoard.istate3[x - 2, y + 4 * i - 2] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 2, y + 4 * i - 2])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x - 2, y + 4 * i - 2];
                                    MoveMentX[INumber] = x - 2;
                                    MoveMentY[INumber] = y + 4 * i - 2;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }

                    }
                }
                }
                if (ChessBoard.istate[x,y]==2)
                {
                    if (ChessBoard.istate1[x, y] == 6)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (x + 1 < 4 && y + 2 * i - 1 > 0 && y + 2 * i - 1 < 8)
                            {
                                if (ChessBoard.istate3[x + 1, y + 2 * i - 1] == 0)
                                {
                                    if (ChessBoard.istate3[x + 2, y + 4 * i - 2] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 2, y + 4 * i - 2])
                                    {
                                        MoveMent[INumber] = ChessBoard.istate3[x + 2, y + 4 * i - 2];
                                        MoveMentX[INumber] = x + 2;
                                        MoveMentY[INumber] = y + 4 * i - 2;
                                        INumber1 = INumber;
                                        INumber++;
                                    }
                                }

                            }
                        }
                        for (int i = 0; i < 2; i++)
                        {
                            if (x - 1 > 0 && y + 2 * i - 1 > 0 && y + 2 * i - 1 < 8)
                            {
                                if (ChessBoard.istate3[x - 1, y + 2 * i - 1] == 0)
                                {
                                    if (ChessBoard.istate3[x - 2, y + 4 * i - 2] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 2, y + 4 * i - 2])
                                    {
                                        MoveMent[INumber] = ChessBoard.istate3[x - 2, y + 4 * i - 2];
                                        MoveMentX[INumber] = x - 2;
                                        MoveMentY[INumber] = y + 4 * i - 2;
                                        INumber1 = INumber;
                                        INumber++;
                                    }
                                }
                            }
                        }
                    }


                    if (ChessBoard.istate1[x, y] == 5)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (x + 1 < 9 && y + 2 * i - 1 > 0 && y + 2 * i - 1 < 8)
                            {
                                if (ChessBoard.istate3[x + 1, y + 2 * i - 1] == 0)
                                {
                                    if (ChessBoard.istate3[x + 2, y + 4 * i - 2] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 2, y + 4 * i - 2])
                                    {
                                        MoveMent[INumber] = ChessBoard.istate3[x + 2, y + 4 * i - 2];
                                        MoveMentX[INumber] = x + 2;
                                        MoveMentY[INumber] = y + 4 * i - 2;
                                        INumber1 = INumber;
                                        INumber++;
                                    }
                                }
                            }
                            if (x - 1 > 5 && y + 2 * i - 1 > 0 && y + 2 * i - 1 < 8)
                            {
                                if (ChessBoard.istate3[x - 1, y + 2 * i - 1] == 0)
                                {
                                    if (ChessBoard.istate3[x - 2, y + 4 * i - 2] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 2, y + 4 * i - 2])
                                    {
                                        MoveMent[INumber] = ChessBoard.istate3[x - 2, y + 4 * i - 2];
                                        MoveMentX[INumber] = x - 2;
                                        MoveMentY[INumber] = y + 4 * i - 2;
                                        INumber1 = INumber;
                                        INumber++;
                                    }
                                }
                            }

                        }
                    }
                }
            }
            //士
            if (ChessBoard.istate2[x, y] == 004)
            {
                if (ChessBoard.istate[x,y]==1)
                {
                 if (ChessBoard.istate1[x, y] == 5)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        if (x + 1 < 3 && y + 2 * i - 1 > 2 && y + 2 * i - 1 < 6)
                        {
                            if (ChessBoard.istate3[x + 1, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 1, y + 2 * i - 1])
                            {
                                MoveMent[INumber] = ChessBoard.istate3[x + 1, y + 2 * i - 1];
                                MoveMentX[INumber] = x + 1;
                                MoveMentY[INumber] = y + 2 * i - 1;
                                INumber1 = INumber;
                                INumber++;
                            }
                        }
                    }
                    for (int i = 0; i < 2; i++)
                    {
                        if (x - 1 >= 0 && y + 2 * i - 1 > 2 && y + 2 * i - 1 < 6)
                        {
                            if (ChessBoard.istate3[x - 1, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 1, y + 2 * i - 1])
                            {
                                MoveMent[INumber] = ChessBoard.istate3[x - 1, y + 2 * i - 1];
                                MoveMentX[INumber] = x - 1;
                                MoveMentY[INumber] = y + 2 * i - 1;
                                INumber1 = INumber;
                                INumber++;
                            }
                        }
                    }
                }
                if (ChessBoard.istate1[x, y] == 6)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        if (x + 1 <= 9 && y + 2 * i - 1 > 2 && y + 2 * i - 1 < 6)
                        {
                            if (ChessBoard.istate3[x + 1, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 1, y + 2 * i - 1])
                            {
                                MoveMent[INumber] = ChessBoard.istate3[x + 1, y + 2 * i - 1];
                                MoveMentX[INumber] = x + 1;
                                MoveMentY[INumber] = y + 2 * i - 1;
                                INumber1 = INumber;
                                INumber++;
                            }
                        }
                        if (x - 1 > 6 && y + 2 * i - 1 > 2 && y + 2 * i - 1 < 6)
                        {
                            if (ChessBoard.istate3[x - 1, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 1, y + 2 * i - 1])
                            {
                                MoveMent[INumber] = ChessBoard.istate3[x - 1, y + 2 * i - 1];
                                MoveMentX[INumber] = x - 1;
                                MoveMentY[INumber] = y + 2 * i - 1;
                                INumber1 = INumber;
                                INumber++;
                            }
                        }
                    }
                }
                }
                if (ChessBoard.istate[x,y]==2)
                {
                    if (ChessBoard.istate1[x, y] == 6)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (x + 1 < 3 && y + 2 * i - 1 > 2 && y + 2 * i - 1 < 6)
                            {
                                if (ChessBoard.istate3[x + 1, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 1, y + 2 * i - 1])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x + 1, y + 2 * i - 1];
                                    MoveMentX[INumber] = x + 1;
                                    MoveMentY[INumber] = y + 2 * i - 1;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                        for (int i = 0; i < 2; i++)
                        {
                            if (x - 1 >= 0 && y + 2 * i - 1 > 2 && y + 2 * i - 1 < 6)
                            {
                                if (ChessBoard.istate3[x - 1, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 1, y + 2 * i - 1])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x - 1, y + 2 * i - 1];
                                    MoveMentX[INumber] = x - 1;
                                    MoveMentY[INumber] = y + 2 * i - 1;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                    }
                    if (ChessBoard.istate1[x, y] == 5)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (x + 1 <= 9 && y + 2 * i - 1 > 2 && y + 2 * i - 1 < 6)
                            {
                                if (ChessBoard.istate3[x + 1, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 1, y + 2 * i - 1])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x + 1, y + 2 * i - 1];
                                    MoveMentX[INumber] = x + 1;
                                    MoveMentY[INumber] = y + 2 * i - 1;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                            if (x - 1 > 6 && y + 2 * i - 1 > 2 && y + 2 * i - 1 < 6)
                            {
                                if (ChessBoard.istate3[x - 1, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 1, y + 2 * i - 1])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x - 1, y + 2 * i - 1];
                                    MoveMentX[INumber] = x - 1;
                                    MoveMentY[INumber] = y + 2 * i - 1;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                    }
                }
            }
            //炮
            if (ChessBoard.istate2[x, y] == 005)
            {
                bool GUNIster = false;
                bool GUNIster1 = false;
                bool GUNIster2 = false;
                bool GUNIster3 = false;
                int kk = 0;
                //上
                for (int i = 1; x + i <= 9; i++)
                {
                    if (ChessBoard.istate3[x + i, y] == 0)
                    {
                        MoveMent[INumber] = ChessBoard.istate3[x + i, y];
                        MoveMentX[INumber] = x + i;
                        MoveMentY[INumber] = y;
                        INumber1 = INumber;
                        INumber++;
                    }
                    if (ChessBoard.istate3[x + i, y] != 0)
                    {
                        kk = x + i;
                        GUNIster = true;
                        break;
                    }
                }
                if (GUNIster == true)
                {
                    for (int j = 1; j + kk <= 9; j++)
                    {
                        if (ChessBoard.istate3[kk + j, y] != 0 && ChessBoard.istate1[x, y] == ChessBoard.istate1[kk + j, y])
                        {
                            break;
                        }
                        if (ChessBoard.istate3[kk + j, y] != 0 && ChessBoard.istate1[x, y] != ChessBoard.istate1[kk + j, y])
                        {
                            MoveMent[INumber] = ChessBoard.istate3[kk + j, y];
                            MoveMentX[INumber] = kk + j;
                            MoveMentY[INumber] = y;
                            INumber1 = INumber;
                            INumber++;
                            break;
                        }
                    }
                    
                }
                //下
                for (int i = 1; x - i >= 0; i++)
                {
                    if (ChessBoard.istate3[x - i, y] == 0)
                    {
                        MoveMent[INumber] = ChessBoard.istate3[x - i, y];
                        MoveMentX[INumber] = x - i;
                        MoveMentY[INumber] = y;
                        INumber1 = INumber;
                        INumber++;
                    }
                    if (ChessBoard.istate3[x - i, y] != 0)
                    {
                        kk = x - i;
                        GUNIster1 = true;
                        break;
                    }
                }
                if (GUNIster1 == true)
                {
                    for (int j = 1; kk - j >= 0; j++)
                    {
                        if (ChessBoard.istate3[kk - j, y] != 0 && ChessBoard.istate1[x, y] == ChessBoard.istate1[kk - j, y])
                        {
                            break;
                        }
                        if (ChessBoard.istate3[kk - j, y] != 0 && ChessBoard.istate1[x, y] != ChessBoard.istate1[kk - j, y])
                        {
                            MoveMent[INumber] = ChessBoard.istate3[kk - j, y];
                            MoveMentX[INumber] = kk - j;
                            MoveMentY[INumber] = y;
                            INumber1 = INumber;
                            INumber++;
                            break;
                        }
                       
                    }
                }
                //左
                for (int i = 1; y + i <= 8; i++)
                {
                    if (ChessBoard.istate3[x, y + i] == 0)
                    {
                        MoveMent[INumber] = ChessBoard.istate3[x, y + i];
                        MoveMentX[INumber] = x;
                        MoveMentY[INumber] = y + i;
                        INumber1 = INumber;
                        INumber++;
                    }
                    if (ChessBoard.istate3[x, y + i] != 0)
                    {
                        kk = y + i;
                        GUNIster2 = true;
                        break;
                    }
                }
                if (GUNIster2 == true)
                {
                    for (int j = 1; kk + j <= 8; j++)
                    {
                        if (ChessBoard.istate3[x, kk + j] != 0 && ChessBoard.istate1[x, y] == ChessBoard.istate1[x, kk + j])
                        {
                            break;
                        }
                        if (ChessBoard.istate3[x, kk + j] != 0 && ChessBoard.istate1[x, y] != ChessBoard.istate1[x, kk + j])
                        {
                            MoveMent[INumber] = ChessBoard.istate3[x, kk + j];
                            MoveMentX[INumber] = x;
                            MoveMentY[INumber] = kk + j;
                            INumber1 = INumber;
                            INumber++;
                            break;
                        }
                    }
                }
                //右
                for (int i = 1; y - i >= 0; i++)
                {
                    if (ChessBoard.istate3[x, y - i] == 0)
                    {
                        MoveMent[INumber] = ChessBoard.istate3[x, y - i];
                        MoveMentX[INumber] = x;
                        MoveMentY[INumber] = y - i;
                        INumber1 = INumber;
                        INumber++;
                    }
                    if (ChessBoard.istate3[x, y - i] != 0)
                    {
                        kk = y - i;
                        GUNIster3 = true;
                        break;
                    }
                }
                if (GUNIster3 == true)
                {
                    for (int j = 1; kk - j >= 0; j++)
                    {
                        if (ChessBoard.istate3[x, kk - j] != 0 && ChessBoard.istate1[x, y] == ChessBoard.istate1[x, kk - j])
                        {
                            break;
                        }
                        if (ChessBoard.istate3[x, kk - j] != 0 && ChessBoard.istate1[x, y] != ChessBoard.istate1[x, kk - j])
                        {
                            MoveMent[INumber] = ChessBoard.istate3[x, kk - j];
                            MoveMentX[INumber] = x;
                            MoveMentY[INumber] = kk - j;
                            INumber1 = INumber;
                            INumber++;
                            break;
                        }
                    }
                }
            }
            //兵
            if (ChessBoard.istate2[x, y] == 006)
            {
                if (ChessBoard.istate[x,y]==1)
                {
                    if (ChessBoard.istate1[x, y] == 5)
                    {
                        if (x + 1 <= 9)
                        {
                            if (ChessBoard.istate3[x + 1, y] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 1, y])
                            {
                                MoveMent[INumber] = ChessBoard.istate3[x + 1, y];
                                MoveMentX[INumber] = x + 1;
                                MoveMentY[INumber] = y;
                                INumber1 = INumber;
                                INumber++;
                            }
                        }
                        if (x + 1 > 5)
                        {
                            for (int i = 0; i < 3; i++)
                            {
                                if (x + i % 2 <= 9 && y + 2 * i - i - 1 >= 0 && y + 2 * i - i - 1 <= 8)
                                {
                                    if (ChessBoard.istate3[x + i % 2, y + 2 * i - i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + i % 2, y + 2 * i - i - 1])
                                    {
                                        MoveMent[INumber] = ChessBoard.istate3[x + i % 2, y + 2 * i - i - 1];
                                        MoveMentX[INumber] = x + i % 2;
                                        MoveMentY[INumber] = y + 2 * i - i - 1;
                                        INumber1 = INumber;
                                        INumber++;
                                    }
                                }
                            }
                        }
                    }
                    if (ChessBoard.istate1[x, y] == 6)
                    {
                        if (x - 1 > 3)
                        {
                            if (ChessBoard.istate3[x - 1, y] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 1, y])
                            {
                                MoveMent[INumber] = ChessBoard.istate3[x - 1, y];
                                MoveMentX[INumber] = x - 1;
                                MoveMentY[INumber] = y;
                                INumber1 = INumber;
                                INumber++;
                            }
                        }
                        if (x - 1 <= 3)
                        {
                            for (int i = 0; i < 3; i++)
                            {
                                if (x - i % 2 >= 0 && y + 2 * i - i - 1 >= 0 && y + 2 * i - i - 1 <= 8)
                                {
                                    if (ChessBoard.istate3[x - i % 2, y + 2 * i - i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - i % 2, y + 2 * i - i - 1])
                                    {
                                        MoveMent[INumber] = ChessBoard.istate3[x - i % 2, y + 2 * i - i - 1];
                                        MoveMentX[INumber] = x - i % 2;
                                        MoveMentY[INumber] = y + 2 * i - i - 1;
                                        INumber1 = INumber;
                                        INumber++;
                                    }
                                }
                            }
                        }
                    }
                }
                if (ChessBoard.istate[x,y]==2)
                {
                    if (ChessBoard.istate1[x, y] == 6)
                    {
                        if (x + 1 <= 9)
                        {
                            if (ChessBoard.istate3[x + 1, y] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 1, y])
                            {
                                MoveMent[INumber] = ChessBoard.istate3[x + 1, y];
                                MoveMentX[INumber] = x + 1;
                                MoveMentY[INumber] = y;
                                INumber1 = INumber;
                                INumber++;
                            }
                        }
                        if (x + 1 > 5)
                        {
                            for (int i = 0; i < 3; i++)
                            {
                                if (x + i % 2 <= 9 && y + 2 * i - i - 1 >= 0 && y + 2 * i - i - 1 <= 8)
                                {
                                    if (ChessBoard.istate3[x + i % 2, y + 2 * i - i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + i % 2, y + 2 * i - i - 1])
                                    {
                                        MoveMent[INumber] = ChessBoard.istate3[x + i % 2, y + 2 * i - i - 1];
                                        MoveMentX[INumber] = x + i % 2;
                                        MoveMentY[INumber] = y + 2 * i - i - 1;
                                        INumber1 = INumber;
                                        INumber++;
                                    }
                                }
                            }
                        }
                    }
                    if (ChessBoard.istate1[x, y] == 5)
                    {
                        if (x - 1 > 3)
                        {
                            if (ChessBoard.istate3[x - 1, y] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - 1, y])
                            {
                                MoveMent[INumber] = ChessBoard.istate3[x - 1, y];
                                MoveMentX[INumber] = x - 1;
                                MoveMentY[INumber] = y;
                                INumber1 = INumber;
                                INumber++;
                            }
                        }
                        if (x - 1 <= 3)
                        {
                            for (int i = 0; i < 3; i++)
                            {
                                if (x - i % 2 >= 0 && y + 2 * i - i - 1 >= 0 && y + 2 * i - i - 1 <= 8)
                                {
                                    if (ChessBoard.istate3[x - i % 2, y + 2 * i - i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x - i % 2, y + 2 * i - i - 1])
                                    {
                                        MoveMent[INumber] = ChessBoard.istate3[x - i % 2, y + 2 * i - i - 1];
                                        MoveMentX[INumber] = x - i % 2;
                                        MoveMentY[INumber] = y + 2 * i - i - 1;
                                        INumber1 = INumber;
                                        INumber++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //将
            if (ChessBoard.istate2[x, y] == 007)
            {
                if (ChessBoard.istate[x,y]==1)
                {
                    if (ChessBoard.istate1[x, y] == 5)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (y + 2 * i - 1 >= 3 && y + 2 * i - 1 <= 5)
                            {
                                if (ChessBoard.istate3[x, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x, y + 2 * i - 1])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x, y + 2 * i - 1];
                                    MoveMentX[INumber] = x;
                                    MoveMentY[INumber] = y + 2 * i - 1;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                        for (int i = 0; i < 2; i++)
                        {
                            if (x + 2 * i - 1 >= 0 && x + 2 * i - 1 <= 2)
                            {
                                if (ChessBoard.istate3[x + 2 * i - 1, y] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 2 * i - 1, y])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x + 2 * i - 1, y];
                                    MoveMentX[INumber] = x + 2 * i - 1;
                                    MoveMentY[INumber] = y;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                    }
                    if (ChessBoard.istate1[x, y] == 6)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (y + 2 * i - 1 >= 3 && y + 2 * i - 1 <= 5)
                            {
                                if (ChessBoard.istate3[x, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x, y + 2 * i - 1])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x, y + 2 * i - 1];
                                    MoveMentX[INumber] = x;
                                    MoveMentY[INumber] = y + 2 * i - 1;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                        for (int i = 0; i < 2; i++)
                        {
                            if (x + 2 * i - 1 >= 7 && x + 2 * i - 1 <= 9)
                            {
                                if (ChessBoard.istate3[x + 2 * i - 1, y] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 2 * i - 1, y])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x + 2 * i - 1, y];
                                    MoveMentX[INumber] = x + 2 * i - 1;
                                    MoveMentY[INumber] = y;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                    }
                }
                if (ChessBoard.istate[x,y]==2)
                {
                    if (ChessBoard.istate1[x, y] == 6)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (y + 2 * i - 1 >= 3 && y + 2 * i - 1 <= 5)
                            {
                                if (ChessBoard.istate3[x, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x, y + 2 * i - 1])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x, y + 2 * i - 1];
                                    MoveMentX[INumber] = x;
                                    MoveMentY[INumber] = y + 2 * i - 1;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                        for (int i = 0; i < 2; i++)
                        {
                            if (x + 2 * i - 1 >= 0 && x + 2 * i - 1 <= 2)
                            {
                                if (ChessBoard.istate3[x + 2 * i - 1, y] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 2 * i - 1, y])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x + 2 * i - 1, y];
                                    MoveMentX[INumber] = x + 2 * i - 1;
                                    MoveMentY[INumber] = y;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                    }
                    if (ChessBoard.istate1[x, y] == 5)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (y + 2 * i - 1 >= 3 && y + 2 * i - 1 <= 5)
                            {
                                if (ChessBoard.istate3[x, y + 2 * i - 1] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x, y + 2 * i - 1])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x, y + 2 * i - 1];
                                    MoveMentX[INumber] = x;
                                    MoveMentY[INumber] = y + 2 * i - 1;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                        for (int i = 0; i < 2; i++)
                        {
                            if (x + 2 * i - 1 >= 7 && x + 2 * i - 1 <= 9)
                            {
                                if (ChessBoard.istate3[x + 2 * i - 1, y] == 0 || ChessBoard.istate1[x, y] != ChessBoard.istate1[x + 2 * i - 1, y])
                                {
                                    MoveMent[INumber] = ChessBoard.istate3[x + 2 * i - 1, y];
                                    MoveMentX[INumber] = x + 2 * i - 1;
                                    MoveMentY[INumber] = y;
                                    INumber1 = INumber;
                                    INumber++;
                                }
                            }
                        }
                    }
                }
            }
  
           // Debug.Log(0000010000000000);
            general();
            finish();
   }
    //第二次点击的位置是否是能到达的目标位置
    //void Component()
    //{
    //    for (int k = 0; k <=INumber1;k++ )
    //    {
    //        if (ChessPositionX2 == MoveMentX[k] && ChessPositionY2 == MoveMentY[k])
    //        {
    //            ss = true; 
    //        }
    //    }
    //}
    //判断将军
    void general()
    {
        sound = false;
        for (int i = 0; i <= INumber1; i++)
        {
            if (ChessBoard.istate2[MoveMentX[i], MoveMentY[i]] == 007)
            {
                if (ChessBoard.istate1[ChessPositionX2, ChessPositionY2] != ChessBoard.istate1[MoveMentX[i], MoveMentY[i]])
                {
                    sound = true;
                }

            }
        }
    }
    //判断输赢
    void finish()
    {
        for (int i = 1; ChessPositionX3 + i + 1 <= 9;i++ )
        {
            if (ChessBoard.istate3[ChessPositionX3 + i, ChessPositionY3] == 0 )
            {
                if (ChessBoard.istate2[ChessPositionX3 + i + 1, ChessPositionY3] == 007 && ChessBoard.istate1[ChessPositionX3, ChessPositionY3] != ChessBoard.istate1[ChessPositionX3 + i + 1, ChessPositionY3])
                {
                    if (ChessBoard.istate1[ChessPositionX3, ChessPositionY3] == 5)
                    {
                        Debug.Log("黑方赢");
                    }
                    else
                        Debug.Log("红方赢");
                }
            }
            if (ChessBoard.istate3[ChessPositionX3 + i, ChessPositionY3]!=0)
            {
                break; 
            }
        }
        for (int i = 1; ChessPositionX3 - i - 1 >=0; i++)
        {
            if (ChessBoard.istate3[ChessPositionX3 - i, ChessPositionY3] == 0)
            {
                if (ChessBoard.istate2[ChessPositionX3 - i - 1, ChessPositionY3] == 007 && ChessBoard.istate1[ChessPositionX3, ChessPositionY3] != ChessBoard.istate1[ChessPositionX3 - i - 1, ChessPositionY3])
                {
                    if (ChessBoard.istate1[ChessPositionX3, ChessPositionY3] == 5)
                    {
                        Debug.Log("黑方赢");
                    }
                    else
                        Debug.Log("红方赢");
                }
            }
            if (ChessBoard.istate3[ChessPositionX3 - i, ChessPositionY3] != 0)
            {
                break;
            }
        }
    }
   public void accept()
    {
        if (ChessBoard.lock1 == true)
        {
            ChessPositionX1 = ChessBoard.Route[0];    //代表Y轴
            ChessPositionY1 = ChessBoard.Route[1];    //代表X轴

            Istar = true;
            if (Istar == true)
            {
                Move(ChessPositionX1, ChessPositionY1);
                Istar = false;
            }
        }
        if (ChessBoard.lock2 == true)
        {
            ChessPositionX2 = ChessBoard.Route[2];
            ChessPositionY2 = ChessBoard.Route[3];
            ChessPositionX3 = ChessBoard.Click[2];
            ChessPositionY3 = ChessBoard.Click[3];
            Debug.Log(ChessPositionX3 + " " + ChessPositionY3);
            //  Debug.Log("2222222222222222222222222");
            //Istar1 = true;
            //if (Istar1 == true)
            //{
            //    ss = false;
            //    Component();

            //    Istar1 = false;
            //}
            //if (ChessBoard.MK == true)
            {
                for (int number = 0; number <= ChessBoard.amount1; number++)
                {
                    seekX[number] = ChessBoard.SeekX[number];
                    seekY[number] = ChessBoard.SeekY[number];
                    Move(seekX[number], seekY[number]);

                }
            }

        }
    }
	// Update is called once per frame
	void Update () {

        accept();
    }
}
}