﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace System.Transfer.Pack
{

    [StructLayout(LayoutKind.Sequential, Pack = 1)]  //变量在内存中的对齐方式
    public class TransferMessage
        	{
            
            public int x1;
            public int y1;
            public int x2;
            public int y2;

            public int RestartSymbol;     //走棋次数
            public int filishClick;       //两次点击完成；
            public int iJuge;             //走棋状态，判断棋子是否能走
            public int win_lose;          //输赢状态
            public int lockstate;         //用来判断克隆克隆方式
            public int StartKey;          //开始
            public int PeaceKey;          //求和
            public int GiveUp;            //认输
            public int Regret;            //悔棋
            public int exit;              //退出
            public int yeskey;            //同意
            public int nokey;             //不同意
            public int itable;            //桌号
            public int itype;             //游戏类型
            public int id;                //玩家ID
            public int iCheck;            //j将军
            //public int state;
           
      
	}


     
}
