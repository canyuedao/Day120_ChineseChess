﻿using UnityEngine;
using System;
using System.Collections;
using System.Clint.Socket;
using System.Transfer.Pack;
using System.VehicleMove.VMove;

public class ChessBoard : MonoBehaviour
{
    public static int[,] istate1 = new int[10, 9];//棋盘坐标状态，区分棋盘坐标上是否为对方棋子
    public static int[,] istate2 = new int[10, 9];//棋盘坐标状态，区分棋盘坐标上是什么棋子
    public static int[,] istate3 = new int[10, 9];//棋盘坐标状态，区分棋盘坐标上是什么棋子
    //int[] RX = new int[20];
   // int[] RY = new int[20];
    public static bool lock1 = false;               //第一次点击棋子锁
    public static bool lock2 = false;               //第二次点击棋子锁
    public static int[] Seekment = new int[16];     //寻找自己的所有棋子
    public static int[] SeekX = new int[16];
    public static int[] SeekY = new int[16];
    int amount;                                        //找到自己棋子的个数
    public static int amount1;
    //public static bool MK = false;
    GameObject[] SS = new GameObject[20];  //  记录标记
    //GameObject[] ChessTab = new GameObject[20];    //记录第二次点击所能走的位置
    public static int[] Click = new int[4];        //寻找将帅的位置
   private VehicleMove acquire = new VehicleMove();
    GameObject MARK1;                              //标记可走的位置
    public AudioSource music;      
    public AudioSource musics;
    public AudioSource musics1;
    public float musicsVolume;
    //bool CollisionState = false; //音效状态

    int saveSymbol;                                   //保存胜负标志

    int showPic;                                      //显示标志
    int regretNum;
    int LockState;                                    //克隆状态 判断克隆红方模式还是黑方模式
    int EatSymbol;                                    //吃子标志
    int SUB_X;                                        //记录点击之后棋盘坐标数组的 X下标
    int SUB_Y;                                        //记录点击之后棋盘坐标数组的 Y下标
    float UP;                                         //棋盘上边界
    float DOWN;                                       //棋盘下边界
    float LEFT;                                       //棋盘左边界
    float RIGHT;                                      //棋盘右边界
    float R;                                          //棋子半径
    float[] ChessX = new float[10];                   //棋盘横坐标数组
    float[] ChessY = new float[9];                    //棋盘纵坐标数组
    GameObject[] sign = new GameObject[2];            //起始地、目的地标识数组
    GameObject[,] CloneObject = new GameObject[10, 9];//克隆出来的对象数组
    public static int number;                         //点击次数
    public static int[] Route = new int[7];           //用来保存一二次点击的棋盘下标
    public static int MoveState;                      //走棋次数
    public string id;                                 //玩家ID（string类型）
    public static int playerID;                       //玩家ID（int 类型）
    public static int RoomNumber;                     //房间号(int)
    public string room;                               //房间（string）
    public int[] memory = new int[5];                 //用于存放每一步棋子的坐标以及当前步是否吃子
    public static int[,] istate = new int[10, 9];     //棋盘坐标状态，区分棋盘坐标上是否有棋子
    Vector2[,] Position = new Vector2[10, 9];         //棋盘坐标数组
    Vector2 PicPositon;                               //图片位置
    Vector2 MarkPosition;                             //走棋标识对象存放位置
    public Texture2D Victory;                         //胜利图片
    public Texture2D Failure;                         //失败图片
    public Texture2D peace;                           //平局图片
    public TransferMessage MessageC;                  //数据包，接收服务器传回来的数据 
    Vector2[] messagePosition = new Vector2[6];       //提示信息位置

    //定义对象变量
    GameObject B_Soldiers;
    GameObject B_Gun;
    GameObject B_Vehicle;
    GameObject B_Horse;
    GameObject B_Minister;
    GameObject B_Bachelor;
    GameObject B_King;
    GameObject R_Soldiers;
    GameObject R_Gun;
    GameObject R_Vehicle;
    GameObject R_Horse;
    GameObject R_Minister;
    GameObject R_Bachelor;
    GameObject R_King;
    GameObject MARK;
    GameObject Save;
    GameObject Duplicate;
    GameObject duplicate;


    void Start()
    {
        musicsVolume = 0.5f;
        music = GameObject.Find("admiral").GetComponent<AudioSource>();
        musics = GameObject.Find("crash").GetComponent<AudioSource>();
        musics1 = GameObject.Find("whop").GetComponent<AudioSource>();
        id = "";
        room = "";
        number = 0;
        LockState = 0;
        saveSymbol = 0;


        showPic = 0;
        UP = 3.05f;
        DOWN = -2.90f;
        LEFT = -2.54f;
        RIGHT = 2.51f;
        R = 0.30f;
        SUB_X = -1;
        SUB_Y = -1;
        Route[4] = 1;

        MARK1       = GameObject.Find("mark1");
        B_Soldiers  = GameObject.Find("BlackSoldier");
        B_Gun       = GameObject.Find("BlackGun");
        B_Vehicle   = GameObject.Find("BlackVehicle");
        B_Horse     = GameObject.Find("BlackHorse");
        B_Minister  = GameObject.Find("BlackMinister");
        B_Bachelor  = GameObject.Find("BlackBachelor");
        B_King      = GameObject.Find("BlackKing");
        R_Soldiers  = GameObject.Find("RedSoldier");
        R_Gun       = GameObject.Find("RedGun");
        R_Vehicle   = GameObject.Find("RedVehicle");
        R_Horse     = GameObject.Find("RedHorse");
        R_Minister  = GameObject.Find("RedMinister");
        R_Bachelor  = GameObject.Find("RedBachelor");
        R_King      = GameObject.Find("RedKing");
        MARK        = GameObject.Find("mark");

        PicPositon.x = -2f;
        PicPositon.y = 0.8f;
        PicPositon = Camera.main.WorldToScreenPoint(PicPositon);
        messagePosition[0].x = -2.4f;
        messagePosition[0].y = -0f;
        messagePosition[1].x = -0.93f;
        messagePosition[1].y = -1.8f;
        messagePosition[2].x = -2.7f;
        messagePosition[2].y = 4.5f;
        messagePosition[3].x = -2.7f;
        messagePosition[3].y = 5.0f;
        messagePosition[4].x = -1.7f;
        messagePosition[4].y = 4.5f;
        messagePosition[5].x = -1.7f;
        messagePosition[5].y = 5.0f;
        MarkPosition.x = -10f;
        MarkPosition.y = 0f;

        for (int i = 0; i < 6; i++)
        {
            messagePosition[i] = Camera.main.WorldToScreenPoint(messagePosition[i]);
        }
        MarkPosition.x = -10f;
        MarkPosition.y = 0f;

        //初始化克隆对象

        //初始化棋盘坐标状态
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                istate[i, j] = 0;
            }
        }
        //求棋盘横坐标
        for (int j = 0; j < 9; j++)
        {
            ChessY[j] = LEFT + (RIGHT - LEFT) / 8 * j;
        }
        //求棋盘纵坐标
        for (int i = 0; i < 10; i++)
        {
            ChessX[i] = DOWN + (UP - DOWN) / 9 * i;
        }
        //求棋盘坐标
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                Position[i, j].x = ChessY[j];
                Position[i, j].y = ChessX[i];
            }
        }
    }
    void OnGUI()
    {
        id = GUI.TextField(new Rect(messagePosition[5].x, Screen.height - messagePosition[5].y, 80, 25), id, 15);
        room = GUI.TextField(new Rect(messagePosition[4].x, Screen.height - messagePosition[4].y, 80, 25), room, 15);
        int.TryParse(id, out playerID);           

        int.TryParse(room, out RoomNumber);
        Debug.Log(playerID);
        GUIStyle psty = new GUIStyle();            //界面绘制
        psty.normal.textColor = Color.black;                                                             //设置字体颜色
        psty.fontSize = 20;                                                                              //设置字体大小
        GUI.Label(new Rect(messagePosition[3].x, Screen.height - messagePosition[3].y, 100, 100), "ID：", psty);
        GUI.Label(new Rect(messagePosition[2].x, Screen.height - messagePosition[2].y, 100, 100), "房间:", psty);



        if (MessageC.win_lose == 1 && (MessageC.GiveUp == 1 && button3.button3_symbol == 0))
        {
            GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Victory);           //绘制图片
            GUI.Label(new Rect(messagePosition[1].x, Screen.height - messagePosition[1].y, 100, 100), "对方认输", psty);
            showPic = 4;
        }
        if (MessageC.win_lose == 1 && (MessageC.GiveUp == 1 && button3.button3_symbol == 1))
        {
            showPic = 5;
        }
        if (MessageC.win_lose == 1 && MessageC.GiveUp == 0)
        {
            if ((MessageC.lockstate + MoveState % 2) == 2)
            {
                showPic = 1;
            }
            else
            {
                showPic = 2;
            }
        }
        if (MessageC.win_lose == 3)
        {
            showPic = 3;
        }
        switch (showPic)
        {
            case 1: 
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Victory);
                    break;
                }
            case 2:
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Failure);
                    break;
                }
            case 3:
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), peace);
                    break;
                }
            case 4:
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Victory);
                    GUI.Label(new Rect(messagePosition[1].x, Screen.height - messagePosition[1].y, 100, 100), "对方认输", psty);
                    break;
                }
            case 5:
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Failure);
                    GUI.Label(new Rect(messagePosition[1].x, Screen.height - messagePosition[1].y, 100, 100), "己方认输", psty);
                    break;
                }
         
        }

        if (MessageC.Regret == 1 && button4.button4_lock == 0)
        {
            GUI.Label(new Rect(messagePosition[0].x, Screen.height - messagePosition[0].y, 100, 100), "对方玩家请求悔棋，是否同意", psty);
        }
        if (MessageC.PeaceKey == 1 && button2.button2_lock == 0)
        {
            GUI.Label(new Rect(messagePosition[0].x, Screen.height - messagePosition[0].y, 100, 100), "对方玩家请求求和，是否同意", psty);
        }
        if (button1.key1 == 1 )
        {
            MoveState = 0;
            if (MessageC.lockstate == 1 && LockState == 0)
            {

                clone_red();
                LockState = 1;
            }
            if (MessageC.lockstate == 2 && LockState == 0)
            {
                clone_black();
                LockState = 2;
            }
        }
        //完成克隆之后 删除最初用来克隆的对象
        if (LockState != 0)
        {
            B_Soldiers.transform.position=MarkPosition;
            B_Gun.transform.position=MarkPosition;     
            B_Vehicle .transform.position=MarkPosition;
            B_Horse.transform.position=MarkPosition;   
            B_Minister.transform.position=MarkPosition;
            B_Bachelor.transform.position=MarkPosition;
            B_King.transform.position=MarkPosition; 
   
            R_Soldiers.transform.position=MarkPosition;
            R_Gun.transform.position=MarkPosition;     
            R_Vehicle.transform.position=MarkPosition; 
            R_Horse .transform.position=MarkPosition;  
            R_Minister.transform.position=MarkPosition;
            R_Bachelor.transform.position=MarkPosition;
            R_King.transform.position=MarkPosition;

            MARK.transform.position = MarkPosition;


            MARK1.transform.position = MarkPosition;
        }
    }


    // 红方玩家克隆
    void clone_red()
    {
        //克隆红黑双方的 車 马 相 士 炮以及将放有棋子的坐标状态值改为1；
        for (int i = 0; i < 2; i++)
        {
            R_Vehicle.transform.position = Position[0, 8 * i];
            CloneObject[0, 8 * i] = Instantiate(R_Vehicle, R_Vehicle.transform.position, R_Vehicle.transform.rotation) as GameObject;
            istate[0, 8 * i] = 1;
            istate1[0, 8 * i] = 5;
            istate2[0, 8 * i] = 001;
            istate3[0, 8 * i] = 1;

            R_Horse.transform.position = Position[0, 6 * i + 1];
            CloneObject[0, 6 * i + 1] = Instantiate(R_Horse, R_Horse.transform.position, R_Horse.transform.rotation) as GameObject;
            istate[0, 6 * i + 1] = 1;
            istate1[0, 6 * i + 1] = 5;
            istate2[0, 6 * i + 1] = 002;
            istate3[0, 6 * i + 1] = 1;

            R_Minister.transform.position = Position[0, 4 * i + 2];
            CloneObject[0, 4 * i + 2] = Instantiate(R_Minister, R_Minister.transform.position, R_Minister.transform.rotation) as GameObject;
            istate[0, 4 * i + 2] = 1;
            istate1[0, 4 * i + 2] = 5;
            istate2[0, 4 * i + 2] = 003;
            istate3[0, 4 * i + 2] = 1;

            R_Bachelor.transform.position = Position[0, 2 * i + 3];
            CloneObject[0, 2 * i + 3] = Instantiate(R_Bachelor, R_Bachelor.transform.position, R_Bachelor.transform.rotation) as GameObject;
            istate[0, 2 * i + 3] = 1;
            istate1[0, 2 * i + 3] = 5;
            istate2[0, 2 * i + 3] = 004;
            istate3[0, 2 * i + 3] = 1;

            R_Gun.transform.position = Position[2, 6 * i + 1];
            CloneObject[2, 6 * i + 1] = Instantiate(R_Gun, R_Gun.transform.position, R_Gun.transform.rotation) as GameObject;
            istate[2, 6 * i + 1] = 1;
            istate1[2, 6 * i + 1] = 5;
            istate2[2, 6 * i + 1] = 005;
            istate3[2, 6 * i + 1] = 1;

            B_Vehicle.transform.position = Position[9, 8 * i];
            CloneObject[9, 8 * i] = Instantiate(B_Vehicle, B_Vehicle.transform.position, B_Vehicle.transform.rotation) as GameObject;
            istate[9, 8 * i] = 2;
            istate1[9, 8 * i] = 6;
            istate2[9, 8 * i] = 001;
            istate3[9, 8 * i] = 1;

            B_Horse.transform.position = Position[9, 6 * i + 1];
            CloneObject[9, 6 * i + 1] = Instantiate(B_Horse, B_Horse.transform.position, B_Horse.transform.rotation) as GameObject;
            istate[9, 6 * i + 1] = 2;
            istate1[9, 6 * i + 1] = 6;
            istate2[9, 6 * i + 1] = 002;
            istate3[9, 6 * i + 1] = 1;

            B_Minister.transform.position = Position[9, 4 * i + 2];
            CloneObject[9, 4 * i + 2] = Instantiate(B_Minister, B_Minister.transform.position, B_Minister.transform.rotation) as GameObject;
            istate[9, 4 * i + 2] = 2;
            istate1[9, 4 * i + 2] = 6;
            istate2[9, 4 * i + 2] = 003;
            istate3[9, 4 * i + 2] = 1;

            B_Bachelor.transform.position = Position[9, 2 * i + 3];
            CloneObject[9, 2 * i + 3] = Instantiate(B_Bachelor, B_Bachelor.transform.position, B_Bachelor.transform.rotation) as GameObject;
            istate[9, 2 * i + 3] = 2;
            istate1[9, 2 * i + 3] = 6;
            istate2[9, 2 * i + 3] = 004;
            istate3[9, 2 * i + 3] = 1;

            B_Gun.transform.position = Position[7, 6 * i + 1];
            CloneObject[7, 6 * i + 1] = Instantiate(B_Gun, B_Gun.transform.position, B_Gun.transform.rotation) as GameObject;
            istate[7, 6 * i + 1] = 2;
            istate1[7, 6 * i + 1] = 6;
            istate2[7, 6 * i + 1] = 005;
            istate3[7, 6 * i + 1] = 1;

        }
        //克隆红黑双方的兵（卒）
        for (int i = 0; i < 5; i++)
        {
            R_Soldiers.transform.position = Position[3, 2 * i];
            CloneObject[3, 2 * i] = Instantiate(R_Soldiers, R_Soldiers.transform.position, R_Soldiers.transform.rotation) as GameObject;
            istate[3, 2 * i] = 1;
            istate1[3, 2 * i] = 5;
            istate2[3, 2 * i] = 006;
            istate3[3, 2 * i] = 1;

            B_Soldiers.transform.position = Position[6, 2 * i];
            CloneObject[6, 2 * i] = Instantiate(B_Soldiers, B_Soldiers.transform.position, B_Soldiers.transform.rotation) as GameObject;
            istate[6, 2 * i] = 2;
            istate1[6, 2 * i] = 6;
            istate2[6, 2 * i] = 006;
            istate3[6, 2 * i] = 1;
        }
        //克隆红黑双方的帅（将）
        R_King.transform.position = Position[0, 4];
        CloneObject[0, 4] = Instantiate(R_King, R_King.transform.position, R_King.transform.rotation) as GameObject;
        istate[0, 4] = 1;
        istate1[0, 4] = 5;
        istate2[0, 4] = 007;
        istate3[0, 4] = 1;

        B_King.transform.position = Position[9, 4];
        CloneObject[9, 4] = Instantiate(B_King, B_King.transform.position, B_King.transform.rotation) as GameObject;
        istate[9, 4] = 2;
        istate1[9, 4] = 6;
        istate2[9, 4] = 007;
        istate3[9, 4] = 1;
    }


    //黑方玩家克隆
    void clone_black()
    {
        //克隆红黑双方的 車 马 相 士 炮以及将放有棋子的坐标状态值改为1；
        for (int i = 0; i < 2; i++)
        {
            B_Vehicle.transform.position = Position[0, 8 * i];
            CloneObject[0, 8 * i] = Instantiate(B_Vehicle, B_Vehicle.transform.position, B_Vehicle.transform.rotation) as GameObject;
            istate[0, 8 * i] = 2;
            istate1[0, 8 * i] = 6;
            istate2[0, 8 * i] = 001;
            istate3[0, 8 * i] = 1;

            B_Horse.transform.position = Position[0, 6 * i + 1];
            CloneObject[0, 6 * i + 1] = Instantiate(B_Horse, B_Horse.transform.position, B_Horse.transform.rotation) as GameObject;
            istate[0, 6 * i + 1] = 2;
            istate1[0, 6 * i + 1] = 6;
            istate2[0, 6 * i + 1] = 002;
            istate3[0, 6 * i + 1] = 1;

            B_Minister.transform.position = Position[0, 4 * i + 2];
            CloneObject[0, 4 * i + 2] = Instantiate(B_Minister, B_Minister.transform.position, B_Minister.transform.rotation) as GameObject;
            istate[0, 4 * i + 2] = 2;
            istate1[0, 4 * i + 2] = 6;
            istate2[0, 4 * i + 2] = 003;
            istate3[0, 4 * i + 2] = 1;

            B_Bachelor.transform.position = Position[0, 2 * i + 3];
            CloneObject[0, 2 * i + 3] = Instantiate(B_Bachelor, B_Bachelor.transform.position, B_Bachelor.transform.rotation) as GameObject;
            istate[0, 2 * i + 3] = 2;
            istate1[0, 2 * i + 3] = 6;
            istate2[0, 2 * i + 3] = 004;
            istate3[0, 2 * i + 3] = 1;

            B_Gun.transform.position = Position[2, 6 * i + 1];
            CloneObject[2, 6 * i + 1] = Instantiate(B_Gun, B_Gun.transform.position, B_Gun.transform.rotation) as GameObject;
            istate[2, 6 * i + 1] = 2;
            istate1[2, 6 * i + 1] = 6;
            istate2[2, 6 * i + 1] = 005;
            istate3[2, 6 * i + 1] = 1;





            R_Vehicle.transform.position = Position[9, 8 * i];
            CloneObject[9, 8 * i] = Instantiate(R_Vehicle, R_Vehicle.transform.position, R_Vehicle.transform.rotation) as GameObject;
            istate[9, 8 * i] = 1;
            istate1[9, 8 * i] = 5;
            istate2[9, 8 * i] = 001;
            istate3[9, 8 * i] = 1;

            R_Horse.transform.position = Position[9, 6 * i + 1];
            CloneObject[9, 6 * i + 1] = Instantiate(R_Horse, R_Horse.transform.position, R_Horse.transform.rotation) as GameObject;
            istate[9, 6 * i + 1] = 1;
            istate1[9, 6 * i + 1] = 5;
            istate2[9, 6 * i + 1] = 002;
            istate3[9, 6 * i + 1] = 1;

            R_Minister.transform.position = Position[9, 4 * i + 2];
            CloneObject[9, 4 * i + 2] = Instantiate(R_Minister, R_Minister.transform.position, R_Minister.transform.rotation) as GameObject;
            istate[9, 4 * i + 2] = 1;
            istate1[9, 4 * i + 2] = 5;
            istate2[9, 4 * i + 2] = 003;
            istate3[9, 4 * i + 2] = 1;

            R_Bachelor.transform.position = Position[9, 2 * i + 3];
            CloneObject[9, 2 * i + 3] = Instantiate(R_Bachelor, R_Bachelor.transform.position, R_Bachelor.transform.rotation) as GameObject;
            istate[9, 2 * i + 3] = 1;
            istate1[9, 2 * i + 3] = 5;
            istate2[9, 2 * i + 3] = 004;
            istate3[9, 2 * i + 3] = 1;

            R_Gun.transform.position = Position[7, 6 * i + 1];
            CloneObject[7, 6 * i + 1] = Instantiate(R_Gun, R_Gun.transform.position, R_Gun.transform.rotation) as GameObject;
            istate[7, 6 * i + 1] = 1;
            istate1[7, 6 * i + 1] = 5;
            istate2[7, 6 * i + 1] = 005;
            istate3[7, 6 * i + 1] = 1;

        }
        //克隆红黑双方的兵（卒）
        for (int i = 0; i < 5; i++)
        {
            B_Soldiers.transform.position = Position[3, 2 * i];
            CloneObject[3, 2 * i] = Instantiate(B_Soldiers, B_Soldiers.transform.position, B_Soldiers.transform.rotation) as GameObject;
            istate[3, 2 * i] = 2;
            istate1[3, 2 * i] = 6;
            istate2[3, 2 * i] = 006;
            istate3[3, 2 * i] = 1;

            R_Soldiers.transform.position = Position[6, 2 * i];
            CloneObject[6, 2 * i] = Instantiate(R_Soldiers, R_Soldiers.transform.position, R_Soldiers.transform.rotation) as GameObject;
            istate[6, 2 * i] = 1;
            istate1[6, 2 * i] = 5;
            istate2[6, 2 * i] = 006;
            istate3[6, 2 * i] = 1;
        }
        //克隆红黑双方的帅（将）
        B_King.transform.position = Position[0, 4];
        CloneObject[0, 4] = Instantiate(B_King, B_King.transform.position, B_King.transform.rotation) as GameObject;
        istate[0, 4] = 2;
        istate1[0, 4] = 6;
        istate2[0, 4] = 007;
        istate3[0, 4] = 1;

        R_King.transform.position = Position[9, 4];
        CloneObject[9, 4] = Instantiate(R_King, R_King.transform.position, R_King.transform.rotation) as GameObject;
        istate[9, 4] = 1;
        istate1[9, 4] = 5;
        istate2[9, 4] = 007;
        istate3[9, 4] = 1;
    }


    IEnumerator OnMouseDown()
    {
        lock1 = false;
        lock2 = false;
        if ((MessageC.lockstate-(MoveState%2)==1)&& MessageC.win_lose == 0)
        {
            CancelTwinkle();
            deleteflag();
            Vector3 MousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Debug.Log(MousePosition.x + "," + MousePosition.y);
            for (int j = 0; j < 9; j++)
            {
                for (int i = 0; i < 10; i++)
                {
                    if ((MousePosition.x - Position[i, j].x) * (MousePosition.x - Position[i, j].x) + (MousePosition.y - Position[i, j].y) * (MousePosition.y - Position[i, j].y) <= R * R)
                    {
                        number++;
                        if (number == 1)
                        {
                            if (istate[i, j] == (2 - LockState % 2))
                            {
                                SUB_X = i;
                                SUB_Y = j;
                                lock1 = true;
                                if (lock1 == true)
                                {
                                    Route[0] = i;
                                    Route[1] = j;
                                    acquire.accept();
                                    hits();
                                }
                                waif();
                                smart();
                            }
                            else number--;
                        }
                        if (number == 2)
                        {
                            Route[5] = MessageC.filishClick;
                            Route[5] = 1;
                            SUB_X = i;
                            SUB_Y = j;
                            lock2 = true;
                            if (lock2 == true)
                            {
                                Route[2] = i;
                                Route[3] = j;
                                deleteflag();
                                yield return new WaitForSeconds(0.0f);
                                acquire.accept();

                            }
                            yield return new WaitForSeconds(0.15f);
                            number = 0;
                        }
                    }
                }
            }
            //闪烁棋子
            if (SUB_X != -1 && SUB_Y != -1)
            {
                if (istate[SUB_X, SUB_Y] == (2 - LockState % 2) && number != 0)
                {
                    InvokeRepeating("conceal", 0, 0.5f);
                    yield return new WaitForSeconds(0.5f);
                    InvokeRepeating("display", 0, 1f);
                }
            }
        }
        Debug.Log(Route[0] + "," + Route[1] + "," + Route[2] + "," + Route[3]);
    }


    //隐藏棋子 作为闪烁棋子的一部分
    void conceal()
    {
        if (istate[SUB_X, SUB_Y] == (2 - LockState % 2))
            CloneObject[SUB_X, SUB_Y].renderer.enabled = false;
    }

    //保存每一步棋子的坐标以及当前步的吃子情况
    //void save()
    //{
    //    if (MessageC.iJuge == 1)
    //    {
    //        memory[MoveState, 0] = datapackage.MessageR.x1;
    //        memory[MoveState, 1] = datapackage.MessageR.y1;
    //        memory[MoveState, 2] = datapackage.MessageR.x2;
    //        memory[MoveState, 3] = datapackage.MessageR.y2;
    //        memory[MoveState, 4] = EatSymbol;
    //    }

    //}

    //悔棋
    //void regret()
    //{
    //    CloneObject[memory[MoveState, 2], memory[MoveState, 3]].renderer.enabled = false;
    //    CloneObject[memory[MoveState, 2], memory[MoveState, 3]].transform.position = Position[memory[MoveState, 0], memory[MoveState, 1]];
    //    CloneObject[memory[MoveState, 0], memory[MoveState, 1]] = Instantiate(CloneObject[memory[MoveState, 2], memory[MoveState, 3]], CloneObject[memory[MoveState, 2], memory[MoveState, 3]].transform.position, CloneObject[memory[MoveState, 2], memory[MoveState, 3]].transform.rotation) as GameObject;
    //    CloneObject[memory[MoveState, 0], memory[MoveState, 1]].renderer.enabled = true;
    //    istate[memory[MoveState, 0], memory[MoveState, 1]] = istate[memory[MoveState, 2], memory[MoveState, 3]];
    //    GameObject.Destroy(CloneObject[memory[MoveState, 2], memory[MoveState, 3]]);
    //    istate[memory[MoveState, 2], memory[MoveState, 3]] = 0;
    //    if (memory[MoveState, 4] == 1)
    //    {
    //        CloneObject[memory[MoveState, 2], memory[MoveState, 3]].renderer.enabled = true;
    //        istate[memory[MoveState, 2], memory[MoveState, 3]] = (2 - LockState % 2) % 2 + 1;
    //    }
    //    for (int i = 0; i < 5; i++)
    //    {
    //        memory[MoveState, i] = 0;
    //    }
    //}
    //显示棋子 作为闪烁棋子的一部分
    void display()
    {
        if (istate[SUB_X, SUB_Y] == (2 - LockState % 2))
            CloneObject[SUB_X, SUB_Y].renderer.enabled = true;
    }
    //保存棋子移动坐标
    void save()
    {
        //if (MessageC.iJuge == 1)
        {
            memory[0] = datapackage.MessageR.x1;
            memory[1] = datapackage.MessageR.y1;
            memory[2] = datapackage.MessageR.x2;
            memory[3] = datapackage.MessageR.y2;
            memory[4] = EatSymbol;
        }

    }

    //悔棋
    void regret()
    {
        CloneObject[memory[2], memory[3]] = Duplicate;
        CloneObject[memory[2], memory[3]].renderer.enabled = false;
        CloneObject[memory[2], memory[3]].transform.position = Position[memory[0], memory[1]];
        CloneObject[memory[0], memory[1]] = Instantiate(CloneObject[memory[2], memory[3]], CloneObject[memory[2], memory[3]].transform.position, CloneObject[memory[2], memory[3]].transform.rotation) as GameObject;
        CloneObject[memory[0], memory[1]].renderer.enabled = true;
        istate[memory[0], memory[1]] = istate[memory[2], memory[3]];
        CloneObject[memory[0], memory[1]] = duplicate;
        GameObject.Destroy(CloneObject[memory[2], memory[3]]);
        if (memory[4] == 1)
        {
            Save.transform.position = Position[memory[2], memory[3]];
            if (istate[memory[2], memory[3]] == 1)
            {
                istate[memory[2], memory[3]] = 2;
            }
            if (istate[memory[2], memory[3]] == 2)
            {
                istate[memory[2], memory[3]] = 1;
            }
        }

    }

    //移动棋子（条件满足，则吃子）
    void move()
    {
        if ((MessageC.x1 != MessageC.x2 || MessageC.y1 != MessageC.y2))
        {
            
            if (istate[MessageC.x2, MessageC.y2] != istate[MessageC.x1, MessageC.y1] && istate[MessageC.x2, MessageC.y2] != 0)
            {
                //GameObject.Destroy(CloneObject[MessageC.x2, MessageC.y2]);//                                         若可以吃子，则删除第二个点击棋子
                CloneObject[MessageC.x2, MessageC.y2].transform.position = MarkPosition;
                Save = CloneObject[MessageC.x2, MessageC.y2];
                istate[MessageC.x2, MessageC.y2] = 0;
                EatSymbol = 1;
            }
            else EatSymbol = 0;
            CloneObject[MessageC.x1, MessageC.y1].renderer.enabled = false;
            CloneObject[MessageC.x1, MessageC.y1].transform.position = Position[MessageC.x2, MessageC.y2];
            CloneObject[MessageC.x2, MessageC.y2] = Instantiate(CloneObject[MessageC.x1, MessageC.y1], CloneObject[MessageC.x1, MessageC.y1].transform.position, CloneObject[MessageC.x1, MessageC.y1].transform.rotation) as GameObject;
            Duplicate = CloneObject[MessageC.x2, MessageC.y2];
            duplicate = CloneObject[MessageC.x1, MessageC.y1];
            CloneObject[MessageC.x2, MessageC.y2].renderer.enabled = true;

            istate[MessageC.x2, MessageC.y2] = istate[MessageC.x1, MessageC.y1];

            istate2[MessageC.x2, MessageC.y2] = istate2[MessageC.x1, MessageC.y1];
            istate2[MessageC.x1, MessageC.y1] = 0;


            istate1[MessageC.x2, MessageC.y2] = istate1[MessageC.x1, MessageC.y1];
            istate1[MessageC.x1, MessageC.y1] = 0;

            istate3[MessageC.x1, MessageC.y1] = 0;
            istate3[MessageC.x2, MessageC.y2] = 1;

            GameObject.Destroy(CloneObject[MessageC.x1, MessageC.y1]);
            istate[MessageC.x1, MessageC.y1] = 0;
        }

    }

    //参数初始化，刷新游戏
    void restart()
    {
        for (int j = 0; j < 9; j++)
        {
            for (int i = 0; i < 10; i++)
            {
                if (istate[i, j] != 0)
                {
                    GameObject.Destroy(CloneObject[i, j]);
                    istate[i, j] = 0;
                }
                if (istate3[i, j] != 0)
                {
                    GameObject.Destroy(CloneObject[i, j]);
                    istate3[i, j] = 0;
                }
            }
        }
        button3.button3_symbol = 0;
        showPic = 0;
        number = 0;
        saveSymbol = 0;
        Route[4] = 1;
        LockState = 0;
        UP = 3.05f;
        DOWN = -2.90f;
        LEFT = -2.54f;
        RIGHT = 2.51f;
        R = 0.30f;
        SUB_X = -1;
        SUB_Y = -1;
        for (int i = 0; i < 20; i++ )
        {
            VehicleMove.MoveMent[i] = 0;
            VehicleMove.MoveMentX[i] = 0;
            VehicleMove.MoveMentY[i] = 0; 
        }
        VehicleMove.INumber1 = -1;
       // Route[4] = 1;
    }


    //生成走棋标记
    void mark()
    {
        //生成第一个标记
        MARK.transform.position = Position[MessageC.x1, MessageC.y1];
        sign[0] = Instantiate(MARK, MARK.transform.position, MARK.transform.rotation) as GameObject;
        //生成第二个标记
        MARK.transform.position = Position[MessageC.x2, MessageC.y2];
        sign[1] = Instantiate(MARK, MARK.transform.position, MARK.transform.rotation) as GameObject;
    }


    //取消闪烁，重新计时
    void CancelTwinkle()
    {
        if (SUB_Y != -1 && SUB_X != -1)
        {
            if (istate[SUB_X, SUB_Y] == (2 - LockState % 2))
            {
                CloneObject[SUB_X, SUB_Y].renderer.enabled = true;                                               //保证上一次点击的象棋处于显示状态
                CancelInvoke("conceal");                                                                         //取消上一次的重复调用
                CancelInvoke("display");                                                                         //取消上一次的重复调用
            }

        }
    }
    //删除上一次生成的标记
    void CancleMark()
    {
        GameObject.Destroy(sign[0]);
        GameObject.Destroy(sign[1]);
    }

    //棋子标记
    void waif()
    {
        for (int m = 0; m <= VehicleMove.INumber1; m++)
        {
            MARK1.transform.position = Position[VehicleMove.MoveMentX[m], VehicleMove.MoveMentY[m]];
            SS[m] = Instantiate(MARK1, MARK1.transform.position, MARK1.transform.rotation) as GameObject;
        }
    }
    //删除标记
    void deleteflag()
    {
        for (int m = 0; m <= VehicleMove.INumber1; m++)        //销毁可走的路径
        {
            GameObject.Destroy(SS[m]);
        }
    }
    //点击声
    void hits()
    {
        if (!musics1.isPlaying && lock1 == true)
        {
            //播放音乐
            musics1.Play();
            Debug.Log("666666666666666666666666666");
        }
    }
    //下落声
    void drop()
    {
        if (!musics.isPlaying)
        {
            //播放音乐
            musics.Play();
             Debug.Log("555555555555555555555555555555");
        }
    }

    //寻找自己的所有棋子
    void search()
    {
        amount = 0;
        amount1 = -1;
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                if (istate1[Route[2], Route[3]] == istate1[i, j])
                {
                    if (ChessBoard.istate[i, j] != 0)
                    {
                        Seekment[amount] = ChessBoard.istate[i, j];
                        SeekX[amount] = i;
                        SeekY[amount] = j;
                        amount1 = amount;
                        amount++;
                    }
                }
            }
        }
        acquire.accept();
    }

    //第一次点击时寻将
    void smart()
    {
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                if (istate1[Route[0], Route[1]] != istate1[i, j] && istate2[i, j] == 007)
                {
                    Click[0] = i;
                    Click[1] = j;
                    break;
                }
            }
        }
    }

    //下落后寻将
    void visit()
    {
        for (int h = 0; h < 10; h++)
        {
            for (int r = 0; r < 9; r++)
            {
                if (istate1[Route[2], Route[3]] == istate1[h, r] && istate2[h, r] == 007)
                {
                    Click[2] = h;
                    Click[3] = r;
                    break;
                }
            }
        }
        acquire.accept();
    }
    //将军声
    void voice()
    {
        if (VehicleMove.sound==true)
        {
            if (!music.isPlaying)
            {
                //播放音乐
                music.Play();
                Debug.Log("give up!!!!!!!!!!!!!!!!!!!");
            }
        }
    }
    // 输赢
    //void Bunko()
    //{
    //    bool life = false;

    //        if (Route[2] == Click[0] && Route[3] == Click[1]&&istate[Click[0],Click[1]]!=istate[Route[0],Route[1]])
    //        {
    //            life = true;
    //        }
    //        if (life == true)
    //        {

    //            if (istate1[Route[2], Route[3]] == 5)
    //            {
    //                Debug.Log("红方赢");
    //            }
    //            else
    //            // if (istate1[Route[2], Route[3]] == 6)
    //            {
    //                Debug.Log("黑方赢");
    //            }
    //        }

    //}
    void Update()
    {

        MARK.transform.position = MarkPosition;
        MessageC = datapackage.MessageR;
        Debug.Log(MessageC.win_lose + "!!!!**************************************输赢");
        Debug.Log(MessageC.PeaceKey + "," + MessageC.Regret + button2.button2_lock + button4.button4_lock);
        Debug.Log(MessageC.x1 + "," + MessageC.y1 + "," + MessageC.x2 + "," + MessageC.y2 + "," + MessageC.iJuge + "," + MoveState + "," + Route[4]);
        Debug.Log(button1.key1+"!!!!!********************************************key1");
        if (MessageC.iJuge == 1)
        {
            if (istate[MessageC.x1, MessageC.y1] != 0 && MessageC.Regret == 0 && MessageC.yeskey == 0)
            {

                if (Route[4] == MoveState)
                {
                    CancleMark();
                    Route[4]++;
                }
                //acquire.accept();
                move();
                drop();
                mark();
                visit();
                search();
                voice();
               // Bunko();
                save();
                MoveState++;
                Debug.Log("!!!!**************************************走棋");
            }
        }
        if (MessageC.exit == 1)
        {            
            Application.Quit();
            Debug.Log("!!!!******************************************退出");
        }

        if (MessageC.win_lose != 0)
        {
            saveSymbol = 1;
        }

        if (saveSymbol == 1 && button1.key1 == 1)
        {
            deleteflag();
            CancleMark();
            restart();
            Debug.Log("!!!!******************************************重置游戏");
            MessageC.win_lose = 0;
            MessageC.iJuge = 0;
            saveSymbol = 0;
        }



        if (datapackage.MessageR.Regret == 1 && datapackage.MessageR.yeskey == 1 && regretNum == 0)
        {

           // if (MoveState >= 1)
            {
               // MoveState--;
                regret();
                CancleMark();
            }
            Debug.Log("!!!!****************************************悔棋");
            regretNum = 1;
            Invoke("reset", 0.5f);
        }
    }
}
