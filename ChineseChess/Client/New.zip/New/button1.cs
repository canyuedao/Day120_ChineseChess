﻿using UnityEngine;
using System.Collections;
//开始按钮
public class button1 : MonoBehaviour
{
    public static int key1;
    int button1_send;
    void Start()
    {
        key1 = 0;
        button1_send = 0;
    }

    void OnMouseDown()
    {
        key1 = 1;
        Invoke("reset", 0.5f);
    }
    void reset()
    {
        key1 = 0;
    }
    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }
    void Update()
    {

    }
}



