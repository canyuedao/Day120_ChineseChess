﻿
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System;
using System.Net;
using System.IO;
using System.Net.Sockets;
using System.Text; 
using System.Threading;
using System.Runtime.Serialization;
using System.Clint.Socket;
using System.Transfer.Pack;

public class datapackage : MonoBehaviour
{
    int num;
    public  int sendnum;
    public static int RecieveState;
    public static int saveState;
    public static int send;
    public static int[] istate = new int[2];
    public static int[] GetMsg = new int[6];
    int[] line = new int[8];
    int[] KeyState = new int[8];
    int[] sendstate = new int[5];
   // [Serializable] // 指示可序列化
   //[StructLayout(LayoutKind.Sequential, Pack = 1)] // 按1字节对齐
   //  public static package data = new package();
    private ClintSocket Sclint;
    //private static ClintSocket NowSocket;
    private TransferMessage Message1;
    public static  TransferMessage MessageR;
   //  Socket clientSocket;
    // Use this for initialization
    void Start()
    {
        Sclint = new ClintSocket();
        Message1 = new TransferMessage();
        MessageR = new TransferMessage();
        Sclint = Sclint.CreatSocket();
        num = 0;
        send = 0;
        sendnum = 0;
        /*ConnectServer();*/
    }
    //void ConnectServer()
    //{
    //    //SocketInformationOptions clientSocket;
    //    clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); //创建Socket对象， 这里我的连接类型是TCP
    //    IPAddress ipAddress = IPAddress.Parse("192.168.1.214");//服务器IP地址
    //    IPEndPoint ipEndpoint = new IPEndPoint(ipAddress, 600);  //服务器端口
    //    clientSocket.Connect(ipEndpoint);

    //}

//     void recieve()
//     {  
//        
//         byte[] response = new byte[Marshal.SizeOf(data)];
//         clientSocket.Blocking = false;
//         int bytesRead = clientSocket.Receive(response);
//        
// 
//         data = (package)BytesToStuct(response, typeof(package));
//         GetMsg[0] = data.x1;
//         GetMsg[1] = data.y1;
//         GetMsg[2] = data.x2;
//         GetMsg[3] = data.y2;
//         GetMsg[4] = data.iJuge;
//         GetMsg[5] = data.iJuge1;
//         Debug.Log(data.x1 + "," + data.y1 + "," + data.x2 + "," + data.y2 + "," + data.iJuge + "," + data.iJuge1);
//         Debug.Log(GetMsg[0]);
//     }
// 
//         void send(byte[] dt)
//         {
// 
//             byte[] concent = dt;
//             clientSocket.Send(concent);
//         
//        }
//      void reset()
//     {
//         sendnum = 1;
//     }
     IEnumerator OnMouseDown()
         {
             yield return new WaitForSeconds(0.1f);
             num = ChessBoard.number;
     
             if (num == 2)
             {
                 line = ChessBoard.Route;
                 Message1.x1 = line[0];
                 Message1.y1 = line[1];
                 Message1.x2 = line[2];
                 Message1.y2 = line[3];
                 Message1.filishClick = line[5];
                 Message1.PeaceKey = KeyState[1];
                 Message1.Regret = KeyState[3];
                 Message1.win_lose = 0;
                 Sclint.SendMessage(Message1);

                 Debug.Log("!!!!************************************点击完成，发送");
                 yield return new WaitForSeconds(0.1f);
                 num = 0;
             };
         }

    ////根据传入的结构体开辟空间然后生成字节数组返回
//     public static byte[] StructToByte<T>(T structType)
//     {
//         int size = Marshal.SizeOf(structType);
//         byte[] bytes = new byte[size];
//         IntPtr structPtr = Marshal.AllocHGlobal(size);
//         Marshal.StructureToPtr(structType, structPtr, false);
//         Marshal.Copy(structPtr, bytes, 0, size);
//         Marshal.FreeHGlobal(structPtr);
//         return bytes;
//     }

    ////根据传入的字节数组开辟空间然后生成结构体返回

//     public static object BytesToStuct(byte[] bytes, Type type)
//     {
//         int size = System.Runtime.InteropServices.Marshal.SizeOf(type);//得到结构体的大小  
//         if (size > bytes.Length) //byte数组长度小于结构体的大小
//         {
//             return null;//返回空
//         }
//         IntPtr structPtr = System.Runtime.InteropServices.Marshal.AllocHGlobal(size);//分配结构体大小的内存空间  
//         System.Runtime.InteropServices.Marshal.Copy(bytes, 0, structPtr, size); //将byte数组拷到分配好的内存空间  
//         object obj = System.Runtime.InteropServices.Marshal.PtrToStructure(structPtr, type); //将内存空间转换为目标结构体
//         System.Runtime.InteropServices.Marshal.FreeHGlobal(structPtr);//释放内存空间
//         return obj;//返回结构体
//     }

     void Update()
     {
         Debug.Log(sendnum+"发送次数");
         send = 0;
         KeyState[0] = key1.yeskey; //同意
         KeyState[1] = button2.KEY2;//求和
         KeyState[2] = button3.key3;//认输
         KeyState[3] = button4.key4;//悔棋
         KeyState[4] = button5.key5;//退出
         KeyState[5] = key2.nokey;  //不同意
         KeyState[6]=button2.button2_state;
         KeyState[7] = button4.button4_state;
         Message1.itype = 1;
         Message1.lockstate = MessageR.lockstate;
         if ((KeyState[1] != 0 || KeyState[3]!=0|| KeyState[4] != 0) && send == 0)   //求和、悔棋、退出
         {
             Message1.PeaceKey = KeyState[1];
             Message1.Regret = KeyState[3];
             Message1.exit = KeyState[4];
             Sclint.SendMessage(Message1);
             send = 1;
             Debug.Log("发送成功！！！::::::::::::::::::::::::::::::::::::::::::求和、悔棋、退出");
         }
         if (KeyState[2] != 0 && send == 0)
         {
             Message1.win_lose = 1;
             Message1.GiveUp = 1;
             Sclint.SendMessage(Message1);
             Debug.Log("发送成功！！！::::::::::::::::::::::::::::::::::::::::::认输");
             send = 4;
         }

         if (KeyState[0] != 0  && send == 0)                                               //同意
         {
             if (MessageR.PeaceKey == 1)
             {
                 Message1.win_lose = 3;
                 Sclint.SendMessage(Message1);
                 Debug.Log("发送成功！！！:::::*************************************同意和棋");
             }
             if (MessageR.Regret == 1)
             {

                 Message1.Regret = 1;
                 Message1.yeskey = 1;
                 Sclint.SendMessage(Message1);
                 Debug.Log("发送成功！！！:::::*************************************同意悔棋");
             }
             send = 2;
         }
         if (KeyState[5] != 0 && send == 0)                                                //不同意
         {

             Message1.PeaceKey = 0;
             Message1.Regret = 0;
             Message1.nokey = KeyState[0];
             Message1.yeskey = KeyState[5];
             Sclint.SendMessage(Message1);
             Debug.Log("发送成功！！！:::::*************************************3333333");
             send = 2;
         }
         if (KeyState[6] == 1||KeyState[7]==1&&send==0)
         {
             Message1.PeaceKey = 0;
             Message1.Regret = 0;
             Message1.nokey = 0;
             Message1.yeskey = 0;
             Sclint.SendMessage(Message1);
             Debug.Log("发送成功！！！:::::*************************************44444444");
             send = 3;
         }
         if (key3.land == 1 && send == 0)
         {
             Message1.id = ChessBoard.playerID;
             Message1.itable = ChessBoard.RoomNumber;
             Message1.win_lose = 0;
             Message1.lockstate = 0;
             Message1.PeaceKey = 0;
             Message1.GiveUp = 0;
             Sclint.SendMessage(Message1);
             Debug.Log("发送成功！！！:::::**********************************发送ID与桌号");
             send = 5;
         }

         Sclint.ReceiveMessage();
         if (Sclint.bReceive == true)
         {
             MessageR = Sclint.ReceiveMessagePack;
             Sclint.ClearReceiveMessagePack();
          }
    }
}