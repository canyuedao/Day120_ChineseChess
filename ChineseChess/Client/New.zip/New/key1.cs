﻿using UnityEngine;
using System.Collections;
//同意按钮
public class key1 : MonoBehaviour {
    public static int yeskey;
    public int key1_send = 0;
    void Start()
    {
        yeskey = 0;

    }
   void  OnMouseDown()
    {
        yeskey = 1;
        
    }
    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }
	// Update is called once per frame
    void Update()
    {
        key1_send = datapackage.send;
        if (key1_send == 2)
        {
            yeskey = 0;
            Debug.Log("YES++++++++++++++++++++++");

        }
    }
}
