﻿using UnityEngine;
using System.Collections;
//悔棋按钮
public class button4 : MonoBehaviour
{
    public static int key4;
    public static int button4_lock = 0;
    public int button4_send;
    public int button4_yes = 0;
    public int button4_no = 0;
    public static int button4_state = 0;
    void Start()
    {
        key4 = 0;
    }
    void OnMouseDown()
    {
        key4 = 1;
        button4_lock = 1;
    }
    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }
    // Update is called once per frame
    void Update()
    {
        button4_send = datapackage.send;
        if (button4_send == 1)
        {
            key4 = 0;
        }
        button4_yes = datapackage.MessageR.yeskey;
        button4_no = datapackage.MessageR.nokey;
        if (button4_no == 1 || button4_yes == 1)
        {
            button4_lock = 0;
            button4_state = 1;
        }
        if (button4_send == 3)
        {
            button4_state = 0;
        }
    }
} 

