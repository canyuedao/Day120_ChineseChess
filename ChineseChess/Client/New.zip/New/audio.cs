﻿using UnityEngine;
using System.Collections;

public class audio : MonoBehaviour {
    //音乐文件
    public AudioSource music;
    Vector2 [] volumeKey= new Vector2[4];
    //音量
    public float musicVolume;
   // int PMusic = 0;
	// Use this for initialization
	void Start () {
        //设置默认音量
        music = GameObject.Find("audio").GetComponent<AudioSource>();
        musicVolume = 0.5f;
        volumeKey[0].x = -3.6f;
        volumeKey[0].y = 1.0f;
        volumeKey[1].x = -3.6f;
        volumeKey[1].y = 1.5f;
        volumeKey[2].x = -3.9f;
        volumeKey[2].y = 1.8f;
        volumeKey[3].x = -3.9f;
        volumeKey[3].y = 2.2f;
        for (int i = 0; i < 4; i++)
        {
            volumeKey[i] = Camera.main.WorldToScreenPoint(volumeKey[i]);
        }
            
	}
    void OnGUI()
    {
        //播放音乐按钮
        GUIStyle kk = new GUIStyle();
        kk.normal.textColor = Color.black;
        if (GUI.Button(new Rect(volumeKey[0].x ,Screen.height-volumeKey[0].y, 30, 20), "PM"))
        {
            //没有播放中
            if (!music.isPlaying)
            {
                //播放音乐
                music.Play();
            }
        }
        if (GUI.Button(new Rect(volumeKey[1].x, Screen.height - volumeKey[1].y, 30, 20), "SM"))
        {
            if (music.isPlaying)
            {
                music.Stop();
               // PMusic = 1;
            }
        }
//         if (GUI.Button(new Rect(50, 0, 30, 20), "MP"))
//         {
//             if (music.isPlaying)
//             {
//                 music.Pause();
//                // PMusic = 1;
//             }
//         }
        musicVolume = GUI.HorizontalSlider(new Rect(volumeKey[2].x, Screen.height - volumeKey[2].y, 50, 20), musicVolume, 0.0f, 1.0f);
        GUI.Label(new Rect(volumeKey[3].x, Screen.height - volumeKey[3].y, 20, 70), "VL:" + (int)(musicVolume * 100) + "%",kk);

      //  if (PMusic == 1)
       // {
            if (music.isPlaying)
            {
                music.volume = musicVolume;
            }
        //}
    }
	// Update is called once per frame
	void Update () {
	
	}
}
