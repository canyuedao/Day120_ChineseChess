﻿using UnityEngine;
using System.Collections;
//认输
public class button3 : MonoBehaviour
{
    public static int key3;
    public static int button3_symbol=0;
    public int button3_send=0;
    void Start()
    {
        key3 = 0;
    }

    void OnMouseDown()
    {
        key3 = 1;
        button3_symbol = 1;
    }
    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }
    void Update()
    {
        button3_send = datapackage.send;
        if (button3_send == 4)
        {
            key3 = 0;
        }
    }
}