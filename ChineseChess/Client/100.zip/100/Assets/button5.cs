﻿using UnityEngine;
using System.Collections;
using System.Clint.Socket;
public class button5 : MonoBehaviour
{

    public static int key5;
    public int button5_send;
  
    private ClintSocket Sclint1;
    void Start()
    {
        key5 = 0;
        button5_send = 0;
    }
   void OnMouseDown()
    {
        key5 = 1;
    }
    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }
    void Update()
    {
        Debug.Log(key5);
        button5_send = datapackage.send;
        if (button5_send == 1)
        {
            key5 = 0;
        }
    }
}
