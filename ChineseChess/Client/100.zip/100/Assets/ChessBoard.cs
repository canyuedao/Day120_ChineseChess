﻿using UnityEngine;
using System;
using System.Collections;
using System.Clint.Socket;
using System.Transfer.Pack;

public class ChessBoard : MonoBehaviour
{
    int showPic;                                      //显示标志
    int regretNum;
    int LockState;                                    //克隆状态 判断克隆红方模式还是黑方模式
    int EatSymbol;                                    //吃子标志
    int SUB_X;                                        //记录点击之后棋盘坐标数组的 X下标
    int SUB_Y;                                        //记录点击之后棋盘坐标数组的 Y下标
    float UP;                                         //棋盘上边界
    float DOWN;                                       //棋盘下边界
    float LEFT;                                       //棋盘左边界
    float RIGHT;                                      //棋盘右边界
    float R;                                          //棋子半径
    float[] ChessX = new float[10];                   //棋盘横坐标数组
    float[] ChessY = new float[9];                    //棋盘纵坐标数组
    GameObject[] sign = new GameObject[2];            //起始地、目的地标识数组
    GameObject[,] CloneObject = new GameObject[10, 9];//克隆出来的对象数组
    public static int number;                         //点击次数
    public static int[] Route = new int[7];           //用来保存一二次点击的棋盘下标
    public static int MoveState;                      //走棋次数
    public string id;                                 //玩家ID（string类型）
    public static int playerID;                       //玩家ID（int 类型）
    public static int RoomNumber;                     //房间号(int)
    public string room;                               //房间（string）
    public int[,] memory = new int[200, 5];           //用于存放每一步棋子的坐标以及当前步是否吃子
    public int[,] istate = new int[10, 9];            //棋盘坐标状态，区分棋盘坐标上是否有棋子
    Vector2[,] Position = new Vector2[10, 9];         //棋盘坐标数组
    Vector2[] player = new Vector2[2];                //玩家位置数组
    Vector2 PicPositon;                               //图片位置
    Vector2 MarkPosition;                             //走棋标识对象存放位置
    public Texture2D Victory;                         //胜利图片
    public Texture2D Failure;                         //失败图片
    public Texture2D peace;                           //平局图片
    public TransferMessage MessageC;                  //数据包，接收服务器传回来的数据 
    Vector2[] messagePosition = new Vector2[2];        //提示信息位置

    //定义对象变量
    GameObject B_Soldiers;
    GameObject B_Gun;
    GameObject B_Vehicle;
    GameObject B_Horse;
    GameObject B_Minister;
    GameObject B_Bachelor;
    GameObject B_King;
    GameObject R_Soldiers;
    GameObject R_Gun;
    GameObject R_Vehicle;
    GameObject R_Horse;
    GameObject R_Minister;
    GameObject R_Bachelor;
    GameObject R_King;
    GameObject MARK;
    GameObject peace1;
    GameObject Victory1;
    GameObject Failure1;

    void Start()
    {
       
        id = "";
        room = "";
        number = 0;
        MoveState = 0;
        LockState = 0;
        showPic = 0;
        UP = 3.05f;
        DOWN = -2.90f;
        LEFT = -2.54f;
        RIGHT = 2.51f;
        R = 0.30f;
        SUB_X = -1;
        SUB_Y = -1;
        Route[4] = 1;


        B_Soldiers  = GameObject.Find("BlackSoldier");
        B_Gun       = GameObject.Find("BlackGun");
        B_Vehicle   = GameObject.Find("BlackVehicle");
        B_Horse     = GameObject.Find("BlackHorse");
        B_Minister  = GameObject.Find("BlackMinister");
        B_Bachelor  = GameObject.Find("BlackBachelor");
        B_King      = GameObject.Find("BlackKing");
        R_Soldiers  = GameObject.Find("RedSoldier");
        R_Gun       = GameObject.Find("RedGun");
        R_Vehicle   = GameObject.Find("RedVehicle");
        R_Horse     = GameObject.Find("RedHorse");
        R_Minister  = GameObject.Find("RedMinister");
        R_Bachelor  = GameObject.Find("RedBachelor");
        R_King      = GameObject.Find("RedKing");
        MARK        = GameObject.Find("mark");
        peace1      = GameObject.Find("peace");
        Victory1    = GameObject.Find("Victory");
        Failure1    = GameObject.Find("Failure");
        PicPositon.x = 0f/*-2f*/;
        PicPositon.y = 0f/*0.8*/;
        PicPositon = Camera.main.WorldToScreenPoint(PicPositon);
        messagePosition[0].x = -2.4f;
        messagePosition[0].y = -0f;
        messagePosition[1].x = -0.93f;
        messagePosition[1].y = -1.8f;

        player[0].x = -3.4f;
        player[0].y = 4.98f;
        player[1].x = -2.50f;
        player[1].y = -3.42f;
        MarkPosition.x = -10f;
        MarkPosition.y = 0f;
        for (int i = 0; i < 2; i++)
        {
            player[i] = Camera.main.WorldToScreenPoint(player[i]);
            messagePosition[i] = Camera.main.WorldToScreenPoint(messagePosition[i]);
        }
        //初始化克隆对象

        //初始化棋盘坐标状态
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                istate[i, j] = 0;
            }
        }
        //求棋盘横坐标
        for (int j = 0; j < 9; j++)
        {
            ChessY[j] = LEFT + (RIGHT - LEFT) / 8 * j;
        }
        //求棋盘纵坐标
        for (int i = 0; i < 10; i++)
        {
            ChessX[i] = DOWN + (UP - DOWN) / 9 * i;
        }
        //求棋盘坐标
        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                Position[i, j].x = ChessY[j];
                Position[i, j].y = ChessX[i];
            }
        }
    }
    void OnGUI()
    {
        id = GUI.TextField(new Rect(280, 0, 80, 25), id, 15);
        room = GUI.TextField(new Rect(280, 30, 80, 25), room, 15);
        int.TryParse(id, out playerID);

        int.TryParse(room, out RoomNumber);
        Debug.Log(playerID);
        GUIStyle psty = new GUIStyle();
        psty.normal.textColor = Color.black;                                                             //设置字体颜色
        psty.fontSize = 20;                                                                              //设置字体大小
        GUI.Label(new Rect(220, 0, 100, 100), "ID：", psty);
        GUI.Label(new Rect(220, 30, 100, 100), "房间：", psty);

        if (MessageC.win_lose == 1 && (MessageC.GiveUp == 1 && button3.button3_symbol == 0))
        {
            GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Victory);
            GUI.Label(new Rect(messagePosition[1].x, Screen.height - messagePosition[1].y, 100, 100), "对方认输", psty);
            showPic = 4;
        }
        if (MessageC.win_lose == 1 && (MessageC.GiveUp == 1 && button3.button3_symbol == 1))
        {
            showPic = 5;
        }
        if (MessageC.win_lose == 1 && MessageC.GiveUp == 0)
        {
            if ((MessageC.lockstate + MoveState % 2) == 2)
            {
                showPic = 1;
            }
            else
            {
                showPic = 2;
            }
        }
        if (MessageC.win_lose == 3)
        {
            showPic = 3;
        }
        switch (showPic)
        {
            case 1: 
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Victory);
                    break;
                }
            case 2:
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Failure);
                    break;
                }
            case 3:
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), peace);
                    break;
                }
            case 4:
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Victory);
                    GUI.Label(new Rect(messagePosition[1].x, Screen.height - messagePosition[1].y, 100, 100), "对方认输", psty);
                    break;
                }
            case 5:
                {
                    GUI.DrawTexture(new Rect(PicPositon.x, Screen.height - PicPositon.y, 200, 100), Failure);
                    GUI.Label(new Rect(messagePosition[1].x, Screen.height - messagePosition[1].y, 100, 100), "己方认输", psty);
                    break;
                }
         
        }

        if (MessageC.Regret == 1 && button4.button4_lock == 0)
        {
            GUI.Label(new Rect(messagePosition[0].x, Screen.height - messagePosition[0].y, 100, 100), "对方玩家请求悔棋，是否同意", psty);
        }
        if (MessageC.PeaceKey == 1 && button2.button2_lock == 0)
        {
            GUI.Label(new Rect(messagePosition[0].x, Screen.height - messagePosition[0].y, 100, 100), "对方玩家请求求和，是否同意", psty);
        }
        if (button1.key1 == 1 )
        {
            if (MessageC.lockstate == 1 && LockState == 0)
            {
                clone_red();
                LockState = 1;
            }
            if (MessageC.lockstate == 2 && LockState == 0)
            {
                clone_black();
                LockState = 2;
            }
        }
        //完成克隆之后 删除最初用来克隆的对象
        if (LockState != 0)
        {
            B_Soldiers.transform.position=MarkPosition;
            B_Gun.transform.position=MarkPosition;     
            B_Vehicle .transform.position=MarkPosition;
            B_Horse.transform.position=MarkPosition;   
            B_Minister.transform.position=MarkPosition;
            B_Bachelor.transform.position=MarkPosition;
            B_King.transform.position=MarkPosition; 
   
            R_Soldiers.transform.position=MarkPosition;
            R_Gun.transform.position=MarkPosition;     
            R_Vehicle.transform.position=MarkPosition; 
            R_Horse .transform.position=MarkPosition;  
            R_Minister.transform.position=MarkPosition;
            R_Bachelor.transform.position=MarkPosition;
            R_King.transform.position=MarkPosition;

            MARK.transform.position = MarkPosition;      
        }
    }

        
    // 红方玩家克隆
    void clone_red()
    {
        //克隆红黑双方的 車 马 相 士 炮以及将放有棋子的坐标状态值改为1；
        for (int i = 0; i < 2; i++)
        {
            R_Vehicle.transform.position = Position[0, 8 * i];
            CloneObject[0, 8 * i] = Instantiate(R_Vehicle, R_Vehicle.transform.position, R_Vehicle.transform.rotation) as GameObject;
            istate[0, 8 * i] = 1;

            R_Horse.transform.position = Position[0, 6 * i + 1];
            CloneObject[0, 6 * i + 1] = Instantiate(R_Horse, R_Horse.transform.position, R_Horse.transform.rotation) as GameObject;
            istate[0, 6 * i + 1] = 1;

            R_Minister.transform.position = Position[0, 4 * i + 2];
            CloneObject[0, 4 * i + 2] = Instantiate(R_Minister, R_Minister.transform.position, R_Minister.transform.rotation) as GameObject;
            istate[0, 4 * i + 2] = 1;

            R_Bachelor.transform.position = Position[0, 2 * i + 3];
            CloneObject[0, 2 * i + 3] = Instantiate(R_Bachelor, R_Bachelor.transform.position, R_Bachelor.transform.rotation) as GameObject;
            istate[0, 2 * i + 3] = 1;

            R_Gun.transform.position = Position[2, 6 * i + 1];
            CloneObject[2, 6 * i + 1] = Instantiate(R_Gun, R_Gun.transform.position, R_Gun.transform.rotation) as GameObject;
            istate[2, 6 * i + 1] = 1;
            B_Vehicle.transform.position = Position[9, 8 * i];
            CloneObject[9, 8 * i] = Instantiate(B_Vehicle, B_Vehicle.transform.position, B_Vehicle.transform.rotation) as GameObject;
            istate[9, 8 * i] = 2;

            B_Horse.transform.position = Position[9, 6 * i + 1];
            CloneObject[9, 6 * i + 1] = Instantiate(B_Horse, B_Horse.transform.position, B_Horse.transform.rotation) as GameObject;
            istate[9, 6 * i + 1] = 2;

            B_Minister.transform.position = Position[9, 4 * i + 2];
            CloneObject[9, 4 * i + 2] = Instantiate(B_Minister, B_Minister.transform.position, B_Minister.transform.rotation) as GameObject;
            istate[9, 4 * i + 2] = 2;

            B_Bachelor.transform.position = Position[9, 2 * i + 3];
            CloneObject[9, 2 * i + 3] = Instantiate(B_Bachelor, B_Bachelor.transform.position, B_Bachelor.transform.rotation) as GameObject;
            istate[9, 2 * i + 3] = 2;

            B_Gun.transform.position = Position[7, 6 * i + 1];
            CloneObject[7, 6 * i + 1] = Instantiate(B_Gun, B_Gun.transform.position, B_Gun.transform.rotation) as GameObject;
            istate[7, 6 * i + 1] = 2;

        }
        //克隆红黑双方的兵（卒）
        for (int i = 0; i < 5; i++)
        {
            R_Soldiers.transform.position = Position[3, 2 * i];
            CloneObject[3, 2 * i] = Instantiate(R_Soldiers, R_Soldiers.transform.position, R_Soldiers.transform.rotation) as GameObject;
            istate[3, 2 * i] = 1;

            B_Soldiers.transform.position = Position[6, 2 * i];
            CloneObject[6, 2 * i] = Instantiate(B_Soldiers, B_Soldiers.transform.position, B_Soldiers.transform.rotation) as GameObject;
            istate[6, 2 * i] = 2;
        }
        //克隆红黑双方的帅（将）
        R_King.transform.position = Position[0, 4];
        CloneObject[0, 4] = Instantiate(R_King, R_King.transform.position, R_King.transform.rotation) as GameObject;
        istate[0, 4] = 1;

        B_King.transform.position = Position[9, 4];
        CloneObject[9, 4] = Instantiate(B_King, B_King.transform.position, B_King.transform.rotation) as GameObject;
        istate[9, 4] = 2;
    }


    //黑方玩家克隆
    void clone_black()
    {
        //克隆红黑双方的 車 马 相 士 炮以及将放有棋子的坐标状态值改为1；
        for (int i = 0; i < 2; i++)
        {
            B_Vehicle.transform.position = Position[0, 8 * i];
            CloneObject[0, 8 * i] = Instantiate(B_Vehicle, B_Vehicle.transform.position, B_Vehicle.transform.rotation) as GameObject;
            istate[0, 8 * i] = 2;

            B_Horse.transform.position = Position[0, 6 * i + 1];
            CloneObject[0, 6 * i + 1] = Instantiate(B_Horse, B_Horse.transform.position, B_Horse.transform.rotation) as GameObject;
            istate[0, 6 * i + 1] = 2;

            B_Minister.transform.position = Position[0, 4 * i + 2];
            CloneObject[0, 4 * i + 2] = Instantiate(B_Minister, B_Minister.transform.position, B_Minister.transform.rotation) as GameObject;
            istate[0, 4 * i + 2] = 2;

            B_Bachelor.transform.position = Position[0, 2 * i + 3];
            CloneObject[0, 2 * i + 3] = Instantiate(B_Bachelor, B_Bachelor.transform.position, B_Bachelor.transform.rotation) as GameObject;
            istate[0, 2 * i + 3] = 2;

            B_Gun.transform.position = Position[2, 6 * i + 1];
            CloneObject[2, 6 * i + 1] = Instantiate(B_Gun, B_Gun.transform.position, B_Gun.transform.rotation) as GameObject;
            istate[2, 6 * i + 1] = 2;





            R_Vehicle.transform.position = Position[9, 8 * i];
            CloneObject[9, 8 * i] = Instantiate(R_Vehicle, R_Vehicle.transform.position, R_Vehicle.transform.rotation) as GameObject;
            istate[9, 8 * i] = 1;

            R_Horse.transform.position = Position[9, 6 * i + 1];
            CloneObject[9, 6 * i + 1] = Instantiate(R_Horse, R_Horse.transform.position, R_Horse.transform.rotation) as GameObject;
            istate[9, 6 * i + 1] = 1;

            R_Minister.transform.position = Position[9, 4 * i + 2];
            CloneObject[9, 4 * i + 2] = Instantiate(R_Minister, R_Minister.transform.position, R_Minister.transform.rotation) as GameObject;
            istate[9, 4 * i + 2] = 1;

            R_Bachelor.transform.position = Position[9, 2 * i + 3];
            CloneObject[9, 2 * i + 3] = Instantiate(R_Bachelor, R_Bachelor.transform.position, R_Bachelor.transform.rotation) as GameObject;
            istate[9, 2 * i + 3] = 1;

            R_Gun.transform.position = Position[7, 6 * i + 1];
            CloneObject[7, 6 * i + 1] = Instantiate(R_Gun, R_Gun.transform.position, R_Gun.transform.rotation) as GameObject;
            istate[7, 6 * i + 1] = 1;

        }
        //克隆红黑双方的兵（卒）
        for (int i = 0; i < 5; i++)
        {
            B_Soldiers.transform.position = Position[3, 2 * i];
            CloneObject[3, 2 * i] = Instantiate(B_Soldiers, B_Soldiers.transform.position, B_Soldiers.transform.rotation) as GameObject;
            istate[3, 2 * i] = 2;

            R_Soldiers.transform.position = Position[6, 2 * i];
            CloneObject[6, 2 * i] = Instantiate(R_Soldiers, R_Soldiers.transform.position, R_Soldiers.transform.rotation) as GameObject;
            istate[6, 2 * i] = 1;
        }
        //克隆红黑双方的帅（将）
        B_King.transform.position = Position[0, 4];
        CloneObject[0, 4] = Instantiate(B_King, B_King.transform.position, B_King.transform.rotation) as GameObject;
        istate[0, 4] = 2;

        R_King.transform.position = Position[9, 4];
        CloneObject[9, 4] = Instantiate(R_King, R_King.transform.position, R_King.transform.rotation) as GameObject;
        istate[9, 4] = 1;
    }
    

    IEnumerator OnMouseDown()
    {
        if ((MessageC.lockstate-(MoveState%2)==1)&& MessageC.win_lose == 0)
        {
            CancelTwinkle();
            Vector3 MousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Debug.Log(MousePosition.x + "," + MousePosition.y);
            for (int j = 0; j < 9; j++)
            {
                for (int i = 0; i < 10; i++)
                {
                    if ((MousePosition.x - Position[i, j].x) * (MousePosition.x - Position[i, j].x) + (MousePosition.y - Position[i, j].y) * (MousePosition.y - Position[i, j].y) <= R * R)
                    {
                        number++;
                        if (number == 1)
                        {
                            if (istate[i, j] == (2 - LockState % 2))
                            {
                                SUB_X = i;
                                SUB_Y = j;
                                Route[0] = i;
                                Route[1] = j;
                            }
                            else number--;
                        }
                        if (number == 2)
                        {
                            Route[5] = MessageC.filishClick;
                            Route[5] = 1;
                            SUB_X = i;
                            SUB_Y = j;
                            Route[2] = i;
                            Route[3] = j;
                            yield return new WaitForSeconds(0.15f);
                            number = 0;
                        }
                    }
                }
            }
            //闪烁棋子
            if (SUB_X != -1 && SUB_Y != -1)
            {
                if (istate[SUB_X, SUB_Y] == (2 - LockState % 2) && number != 0)
                {
                    InvokeRepeating("conceal", 0, 0.5f);
                    yield return new WaitForSeconds(0.5f);
                    InvokeRepeating("display", 0, 1f);
                }
            }
        }
        Debug.Log(Route[0] + "," + Route[1] + "," + Route[2] + "," + Route[3]);
    }


    //隐藏棋子 作为闪烁棋子的一部分
    void conceal()
    {
        if (istate[SUB_X, SUB_Y] == (2 - LockState % 2))
            CloneObject[SUB_X, SUB_Y].renderer.enabled = false;
    }

    //保存每一步棋子的坐标以及当前步的吃子情况
    //void save()
    //{
    //    if (MessageC.iJuge == 1)
    //    {
    //        memory[MoveState, 0] = datapackage.MessageR.x1;
    //        memory[MoveState, 1] = datapackage.MessageR.y1;
    //        memory[MoveState, 2] = datapackage.MessageR.x2;
    //        memory[MoveState, 3] = datapackage.MessageR.y2;
    //        memory[MoveState, 4] = EatSymbol;
    //    }

    //}

    //悔棋
    //void regret()
    //{
    //    CloneObject[memory[MoveState, 2], memory[MoveState, 3]].renderer.enabled = false;
    //    CloneObject[memory[MoveState, 2], memory[MoveState, 3]].transform.position = Position[memory[MoveState, 0], memory[MoveState, 1]];
    //    CloneObject[memory[MoveState, 0], memory[MoveState, 1]] = Instantiate(CloneObject[memory[MoveState, 2], memory[MoveState, 3]], CloneObject[memory[MoveState, 2], memory[MoveState, 3]].transform.position, CloneObject[memory[MoveState, 2], memory[MoveState, 3]].transform.rotation) as GameObject;
    //    CloneObject[memory[MoveState, 0], memory[MoveState, 1]].renderer.enabled = true;
    //    istate[memory[MoveState, 0], memory[MoveState, 1]] = istate[memory[MoveState, 2], memory[MoveState, 3]];
    //    GameObject.Destroy(CloneObject[memory[MoveState, 2], memory[MoveState, 3]]);
    //    istate[memory[MoveState, 2], memory[MoveState, 3]] = 0;
    //    if (memory[MoveState, 4] == 1)
    //    {
    //        CloneObject[memory[MoveState, 2], memory[MoveState, 3]].renderer.enabled = true;
    //        istate[memory[MoveState, 2], memory[MoveState, 3]] = (2 - LockState % 2) % 2 + 1;
    //    }
    //    for (int i = 0; i < 5; i++)
    //    {
    //        memory[MoveState, i] = 0;
    //    }
    //}
    //显示棋子 作为闪烁棋子的一部分
    void display()
    {
        if (istate[SUB_X, SUB_Y] == (2 - LockState % 2))
            CloneObject[SUB_X, SUB_Y].renderer.enabled = true;
    }

    //移动棋子（条件满足，则吃子）
    void move()
    {
        if ((MessageC.x1 != MessageC.x2 || MessageC.y1 != MessageC.y2))
        {
            if (istate[MessageC.x2, MessageC.y2] != istate[MessageC.x1, MessageC.y1] && istate[MessageC.x2, MessageC.y2] != 0)
            {
                GameObject.Destroy(CloneObject[MessageC.x2, MessageC.y2]);//                                         若可以吃子，则删除第二个点击棋子
                istate[MessageC.x2, MessageC.y2] = 0;
                EatSymbol = 1;
            }
            else EatSymbol = 0;
            CloneObject[MessageC.x1, MessageC.y1].renderer.enabled = false;
            CloneObject[MessageC.x1, MessageC.y1].transform.position = Position[MessageC.x2, MessageC.y2];
            CloneObject[MessageC.x2, MessageC.y2] = Instantiate(CloneObject[MessageC.x1, MessageC.y1], CloneObject[MessageC.x1, MessageC.y1].transform.position, CloneObject[MessageC.x1, MessageC.y1].transform.rotation) as GameObject;
            CloneObject[MessageC.x2, MessageC.y2].renderer.enabled = true;
            istate[MessageC.x2, MessageC.y2] = istate[MessageC.x1, MessageC.y1];
            GameObject.Destroy(CloneObject[MessageC.x1, MessageC.y1]);
            istate[MessageC.x1, MessageC.y1] = 0;
        }

    }

    //参数初始化，刷新游戏
    void restart()
    {
        for (int j = 0; j < 9; j++)
        {
            for (int i = 0; i < 10; i++)
            {
                if (istate[i, j] != 0)
                {
                    GameObject.Destroy(CloneObject[i, j]);
                    istate[i, j]=0;
                }
            }
        }
        showPic = 0;
        number = 0;
        MoveState = 0;
        Route[4] = 0;
        LockState = 0;
        UP = 3.05f;
        DOWN = -2.90f;
        LEFT = -2.54f;
        RIGHT = 2.51f;
        R = 0.30f;
        SUB_X = -1;
        SUB_Y = -1;
        Route[4] = 1;

    }
    //生成走棋标记
    void mark()
    {
        //生成第一个标记
        MARK.transform.position = Position[MessageC.x1, MessageC.y1];
        sign[0] = Instantiate(MARK, MARK.transform.position, MARK.transform.rotation) as GameObject;
        //生成第二个标记
        MARK.transform.position = Position[MessageC.x2, MessageC.y2];
        sign[1] = Instantiate(MARK, MARK.transform.position, MARK.transform.rotation) as GameObject;
    }


    //取消闪烁，重新计时
    void CancelTwinkle()
    {
        if (SUB_Y != -1 && SUB_X != -1)
        {
            if (istate[SUB_X, SUB_Y] == (2 - LockState % 2))
            {
                CloneObject[SUB_X, SUB_Y].renderer.enabled = true;                                               //保证上一次点击的象棋处于显示状态
                CancelInvoke("conceal");                                                                         //取消上一次的重复调用
                CancelInvoke("display");                                                                         //取消上一次的重复调用
            }

        }
    }
    //删除上一次生成的标记
    void CancleMark()
    {
        GameObject.Destroy(sign[0]);
        GameObject.Destroy(sign[1]);
    }
    void Update()
    {

        MARK.transform.position = MarkPosition;
        MessageC = datapackage.MessageR;
        Debug.Log(MessageC.win_lose + "!!!!**************************************输赢");
        Debug.Log(MessageC.PeaceKey + "," + MessageC.Regret + button2.button2_lock + button4.button4_lock);
        Debug.Log(MessageC.x1 + "," + MessageC.y1 + "," + MessageC.x2 + "," + MessageC.y2 + "," + MessageC.iJuge + "," + MoveState + "," + Route[4]);
        Debug.Log(button1.key1+"!!!!!********************************************key1");
        if (MessageC.iJuge == 1)
        {
            if (istate[MessageC.x1, MessageC.y1] != 0 && MessageC.Regret == 0 && MessageC.yeskey == 0)
            {

                if (Route[4] == MoveState)
                {
                    CancleMark();
                    Route[4]++;
                }
                move();
                mark();
//                save();
                MoveState++;
                Debug.Log("!!!!**************************************走棋");
            }
        }
        if (MessageC.exit == 1)
        {            
            Application.Quit();
            Debug.Log("!!!!******************************************退出");
        }
        if (MessageC.win_lose != 0&&button1.key1==1)
        {
            CancleMark();
            restart();
            Debug.Log("!!!!******************************************重置游戏");
            MessageC.win_lose = 0;
            MessageC.iJuge = 0;
        }

    //    if (datapackage.MessageR.Regret == 1 && datapackage.MessageR.yeskey == 1 && regretNum == 0)
    //    {

    //        if (MoveState >= 1)
    //        {
    //            MoveState--;
    //            regret();
    //            CancleMark();
    //        }
    //        Debug.Log("!!!!****************************************悔棋");
    //        regretNum = 1;
    //        Invoke("reset", 0.5f);
    //    }
    }
}
