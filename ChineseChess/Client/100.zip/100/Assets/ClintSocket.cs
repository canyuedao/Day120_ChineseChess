﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Transfer.Pack;

namespace System.Clint.Socket
{
    public class ClintSocket
    {

        private static ClintSocket NowSocket;
        private TcpClient _client;
        private byte[] data;
        public TransferMessage ReceiveMessagePack;
        public bool bReceive = false;
        string message = "";

        public ClintSocket CreatSocket()
        {
            if (NowSocket == null)
            {
                NowSocket = new ClintSocket();
                NowSocket.ClientConnect("127.0.0.1", 600);
            }
            return NowSocket;
        }

        public TransferMessage GetReceiveMessage()
        {
            ReceiveMessage();
            return ReceiveMessagePack;
        }

        public void ClearReceiveMessagePack()
        {
            bReceive = false;
            //             ReceiveMessagePack.ComOrder1 = 0;
            //             ReceiveMessagePack.ComOrder2 = 0;
            //             ReceiveMessagePack.ComOrder3 = 0;
            //             ReceiveMessagePack.SendTOID = 0;
            //             ReceiveMessagePack.uerID = 0;
            //             ReceiveMessagePack.Num1 = 0;
            //             ReceiveMessagePack.Num2 = 0;
            //             ReceiveMessagePack.Num3 = 0;
            //             ReceiveMessagePack.Num4 = 0;
            //             ReceiveMessagePack.Num5 = 0;
            //             ReceiveMessagePack.Num6 = 0;
            //             ReceiveMessagePack.Num7 = 0;
            //ReceiveMessagePack.ComOrder1 = 0;
        }

        public string GetRemessage()
        {
            return message;
        }
        //连接服务器
        public void ClientConnect(string chostName, int vPort)
        {
            this._client = new TcpClient();
            this._client.Connect(chostName, vPort);

            data = new byte[this._client.ReceiveBufferSize];
        }

        //结构体转字节组（打包数据）
        private static byte[] StructToBytes<T>(T obj)
        {
            int size = Marshal.SizeOf(typeof(T));
            IntPtr bufferPtr = Marshal.AllocHGlobal(size);
            try
            {
                Marshal.StructureToPtr(obj, bufferPtr, false);
                byte[] bytes = new byte[size];
                Marshal.Copy(bufferPtr, bytes, 0, size);

                return bytes;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in StructToBytes ! " + ex.Message);
            }
            finally
            {
                Marshal.FreeHGlobal(bufferPtr);
            }
        }

        //字节流转换成结构体（数据解包）
        private static T BytesToStruct<T>(byte[] bytes, int startIndex = 0)
        {
            if (bytes == null) return default(T);
            if (bytes.Length <= 0) return default(T);
            int objLength = Marshal.SizeOf(typeof(T));
            IntPtr bufferPtr = Marshal.AllocHGlobal(objLength);
            try//struct_bytes转换
            {
                Marshal.Copy(bytes, startIndex, bufferPtr, objLength);
                return (T)Marshal.PtrToStructure(bufferPtr, typeof(T));
            }
            catch (Exception ex)
            {
                throw new Exception("Error in BytesToStruct ! " + ex.Message);
            }
            finally
            {
                Marshal.FreeHGlobal(bufferPtr);
            }
        }

        //数据发送
        public void SendMessage(TransferMessage vSendMessagePack)
        {

            byte[] data = StructToBytes<TransferMessage>(vSendMessagePack);
            try
            {
                NetworkStream ns = this._client.GetStream();

                // byte[] data = System.Text.Encoding.ASCII.GetBytes(message);

                /*            Pack1 =(PransmissionPack)data;*/
                ns.Write(data, 0, data.Length);
                ns.Flush();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString());
            }
        }


        private void Receive(IAsyncResult ar)
        {
            try
            {
                int bytesRead;

                bytesRead = this._client.GetStream().EndRead(ar);

                if (bytesRead < 1)
                {

                    return;
                }
                else
                {

                    // Debug.Log(System.Text.Encoding.ASCII.GetString(data, 0, bytesRead));
                    ReceiveMessagePack = BytesToStruct<TransferMessage>(data, 0);
                    bReceive = true;
                    message += System.Text.Encoding.ASCII.GetString(data, 0, bytesRead);
                }

                this._client.GetStream().BeginRead(data, 0, System.Convert.ToInt32(this._client.ReceiveBufferSize), Receive, null);


            }
            catch (Exception ex)
            {

            }
        }
        //数据接收
        public void ReceiveMessage()
        {
            this._client.GetStream().BeginRead(data, 0, System.Convert.ToInt32(this._client.ReceiveBufferSize), Receive, null);
        }

    }

}
