﻿using UnityEngine;
using System.Collections;
//求和按钮
public class button2 : MonoBehaviour
{
    public static int KEY2;
    public int button2_send;
    public int button_yes = 0;
    public int button_no = 0;
    public static int button2_lock = 0;
    public static int button2_state = 0;
    void Start()
    {
        KEY2 = 0;
    }

    void OnMouseDown()
    {
        KEY2 = 1;
        button2_lock = 1;
    }
    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }

    void Update()
    {
        button2_send = datapackage.send;
        if (button2_send == 1)
        {
            KEY2 = 0;
        }
//            Debug.Log(button_no + "," + datapackage.MessageR.yeskey + "BUTTON************");
                button_yes = datapackage.MessageR.yeskey;
                button_no = datapackage.MessageR.nokey;
                if (button_no == 1 || button_yes == 1)
                {
                   button2_lock = 0;
                   button2_state = 1;
                }
                if (datapackage.send == 3)
                {
                    button2_state = 0;
                    Debug.Log(button_no + "," + datapackage.MessageR.yeskey + "BUTTON************666666666666666666666666666");
                }

        
    }

}
