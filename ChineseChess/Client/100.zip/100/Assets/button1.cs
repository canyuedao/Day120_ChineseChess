﻿using UnityEngine;
using System.Collections;

public class button1 : MonoBehaviour
{
    public static int key1;
    int button1_send;
    void Start()
    {
        key1 = 0;
        button1_send = 0;
    }

    void OnMouseDown()
    {
           key1=1;
        
    }

    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }
    void Update()
    {
        button1_send = ChessBoard.number;
        if (button1_send == 1)
        {
            key1 = 0;
        }
    }
}
