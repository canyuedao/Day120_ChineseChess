﻿using UnityEngine;
using System.Collections;

public class key3 : MonoBehaviour {
    public static int land = 0;
	// Use this for initialization
	void Start () {
	
	}
    void OnMouseDown()
    {
        if (land == 0)
        {
            land = 1;
        }
        
    }
    void OnMouseEnter()
    {
        renderer.material.color = Color.grey;
    }
    void OnMouseExit()
    {
        renderer.material.color = Color.white;
    }
	void Update () {
	
	}
}
